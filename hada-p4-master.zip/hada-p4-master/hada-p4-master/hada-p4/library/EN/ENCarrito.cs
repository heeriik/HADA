﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using library;
using System.Web;
using System.Data.SqlClient;



namespace library
{
    public class ENCarrito
    {
        private int _id_carrito;
        private int _id_usuario;

        public int id_carrito
        {
            get
            {return this._id_carrito;}
            set
            {this._id_carrito = value;}
        }

        public int id_usuario
        {
            get
            { return this._id_usuario; }
            set
            { this._id_usuario = value; }
        }
        
        //Constructor por defecto
        public ENCarrito() 
        {
            id_usuario = -1;
        }
        
        //Constructor de copia
        public ENCarrito(int id_usu) 
        {
            this.id_usuario = id_usu;
        }

        public ENCarrito(int id_usuario, int id_carrito )
        {
            this.id_usuario = id_usuario;
            this.id_carrito = id_carrito;
        }
        //Metodo para crear un carrito vacio
        public bool createCarrito() 
        {
            CADCarrito carrito = new CADCarrito();

            if (!carrito.readCarrito(this)) 
            {
                return carrito.createCarrito(this);
            }
            else
            {
                return false;
            }
        }

        //Metodo para actualizar un carrito (No se si sera necesario)
        public bool updateCarrito() { return false; }

        //Metodo para eliminar el carrito
        public bool deleteCarrito() 
        {
            return new CADCarrito().deleteCarrito(this);
        }

        //Metodo para leer el carrito
        public bool readCarrito() 
        {
            return new CADCarrito().readCarrito(this);
        }

        public void VaciarCarrito(int id_usuario)
        {
            ENCarrito carrito = new ENCarrito(id_usuario);

            carrito.readCarrito();

            ENLinCarrito linCarrito = new ENLinCarrito();

            linCarrito.id_carrito = carrito.id_carrito;

            DataSet data = linCarrito.getLinCarrito();

            ENJuego aux = new ENJuego();

            foreach (DataRow row in data.Tables[0].Rows)
            {
                aux.id_juego = int.Parse(row["id_juego"].ToString());

                aux.ReadJuego();

                ENLinCarrito borrar = new ENLinCarrito(new CADCarrito().UserTieneCarrito(id_usuario), aux.id_juego);

                new CADLinCarrito().deleteLinCarrito(borrar);

            }
        }

        public bool MeterEnCarrito(int id_juego,int id_usuario)
        {

            ENUsuario usuario = CADUsuario.ObtenerUsuarioPorId(id_usuario);

            CADCarrito c = new CADCarrito();

            ENCarrito carrito = new ENCarrito(usuario.id_usuario);


            if (c.UserTieneCarrito(usuario.id_usuario) == -1)
            {
                c.createCarrito(carrito);
            }

            carrito.readCarrito();

            ENLinCarrito linCarrito = new ENLinCarrito(carrito.id_carrito,id_juego);

            if(!new CADLinCarrito().readLinCarrito(linCarrito))
            {
                if(!new CADJuego().UsuarioHaCompradoJuego(usuario.id_usuario, id_juego)) 
                {
                    new CADLinCarrito().createLinCarrito(linCarrito);

                    return true;
                }
  
            }

            return false;
        }

        



    }
}