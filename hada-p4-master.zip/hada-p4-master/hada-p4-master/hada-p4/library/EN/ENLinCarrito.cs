﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace library
{
    public class ENLinCarrito
    {
        private int _id_carrito;
        private int _id_linea;
        private int _id_juego;

        public int id_carrito
        {
            get
            {
                return _id_carrito;
            }

            set
            {
                this._id_carrito = value;
            }
        }

        public int id_linea
        {
            get
            {
                return _id_linea;
            }

            set
            {
                this._id_linea = value;
            }
        }

        public int id_juego
        {
            get
            {
                return _id_juego;
            }

            set
            {
                this._id_juego = value;
            }
        }


        //Constructor por defecto
        public ENLinCarrito() 
        {
            id_carrito = -1;
            id_juego = -1;
        }

        //Constructor de copia
        public ENLinCarrito(int id_car,int juego) 
        {
            this.id_carrito = id_car;
            this.id_juego = juego;
        }

        //Metodo para crear una linea de carrito
        public bool createLinCarrito() 
        {
            CADLinCarrito linCarrito = new CADLinCarrito();

            if (!linCarrito.readLinCarrito(this))
            {
                return linCarrito.createLinCarrito(this);
            }
            else
            {
                return false;
            }
        }

        //Metodo para leer una linea de carrito
        public bool readLinCarrito() 
        {
            return new CADLinCarrito().readLinCarrito(this); 
        }

        //Metodo para acutalizar una linea de carrito (No se si sera necesario)
        public bool updateLinCarrito() { return false; }

        //Metodo para eliminar una linea de carrito
        public bool deleteLinCarrito() 
        { 
            return new CADLinCarrito().deleteLinCarrito(this); 
        }

        //Metodo para obtener todas las lineas de un carrito
        public DataSet getLinCarrito() 
        { 
            return new CADLinCarrito().getLinCarrito(this); 
        }
    }
}

