﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace library
{
    public class ENLinFactura
    {
        private int _id_lin_factura;
        private int _id_factura;
        private int _id_juego;
        private decimal _precio_unitario;


        public int id_lin_factura
        {
            get { return _id_lin_factura; }
            set { _id_lin_factura = value; }
        }
        public int id_factura
        {
            get { return _id_factura; }
            set { _id_factura = value; }
        }
        public int id_juego
        {
            get { return _id_juego; }
            set { _id_juego = value; }
        }
        public decimal precio_unitario
        {
            get { return _precio_unitario; }
            set { _precio_unitario = value; }
        }

        public ENLinFactura()
        {
 
        }

        public ENLinFactura(int id_lin_factura, int id_factura, int id_juego, int precio_unitario)
        {
            _id_lin_factura = id_lin_factura;
            _id_factura = id_factura;
            _id_juego = id_juego;
            _precio_unitario = precio_unitario;
        }

        public ENLinFactura(int id_factura, int id_juego, int precio_unitario)
        {
            this.id_factura = id_factura;
            this.id_juego = id_juego;
            this.precio_unitario = precio_unitario;
        }

        public bool createLinFactura()
        {
            CADLinFactura cadLinFactura = new CADLinFactura();
            return cadLinFactura.createLinFactura(this);
        }

        public bool readLinFactura()
        {
            CADLinFactura cadLinFactura = new CADLinFactura();
            return cadLinFactura.readLinFactura(this);
        }


    }
}