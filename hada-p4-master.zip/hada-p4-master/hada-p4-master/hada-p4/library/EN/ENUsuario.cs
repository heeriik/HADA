﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENUsuario
    {
        private int _id_usuario;
        private string _nombre_usuario;
        private string _correo;
        private decimal _saldo_disponible;
        private string _contrasena;
        private bool _admin;

        public int id_usuario
        {
            get { return _id_usuario; }
            set { _id_usuario = value; }
        }
        public string nombre_usuario
        {
            get { return _nombre_usuario; }
            set { _nombre_usuario = value; }
        }
        public string correo
        {
            get { return _correo; }
            set { _correo = value; }
        }
        public decimal saldo_disponible
        {
            get { return _saldo_disponible; }
            set { _saldo_disponible = value; }
        }
        public string contrasena
        {
            get { return _contrasena; }
            set { _contrasena = value; }
        }
        public bool admin
        {
            get { return _admin; }
            set { _admin = value; }
        }
        
        public ENUsuario()
        {

        }
        public ENUsuario(ENUsuario usuario)
        {
            this._id_usuario = usuario._id_usuario;
            this._nombre_usuario = usuario._nombre_usuario;
            this._correo = usuario._correo;
            this._saldo_disponible = usuario._saldo_disponible;
            this._contrasena = usuario._contrasena;
            this._admin = usuario._admin;
        }
        public ENUsuario(int id_usuario, string nombre_usuario, string correo, decimal saldo, string contraseña, bool admin)
        {
            this._id_usuario = id_usuario;
            this._nombre_usuario = nombre_usuario;
            this._correo = correo;
            this._saldo_disponible = saldo;
            this._contrasena = contraseña;
            this._admin = admin;
        }
        public bool create()
        {
            return CADUsuario.create(this);
        }
        public bool read()
        {
            return CADUsuario.read(this);
        }
        public bool update()
        {
            return CADUsuario.update(this);
        }
        public bool delete()
        {
            return CADUsuario.delete(this);
        }
        public bool ValidarCredenciales(string correo, string contraseña)
        {
            return CADUsuario.ValidarCredenciales(correo, contraseña);
        }
        public int ObtenerIdUsuario(string correo)
        {
            return CADUsuario.ObtenerIdUsuario(correo);
        }
        public bool ExisteCorreo(string correo)
        {
            return CADUsuario.ExisteCorreo(correo);
        }
        public ENUsuario ObtenerUsuarioPorId(int id)
        {
            return CADUsuario.ObtenerUsuarioPorId(id);
        }
        public List<ENUsuario> ObtenerUsuarios()
        {
            return CADUsuario.ObtenerUsuarios();
        }
        public bool ActualizarUsuario()
        {
            return CADUsuario.ActualizarUsuario(this);
        }
        public bool AgregarSaldo(int id, decimal importe)
        {
            return CADUsuario.AgregarImporte(id, importe);
        }
    }
}
