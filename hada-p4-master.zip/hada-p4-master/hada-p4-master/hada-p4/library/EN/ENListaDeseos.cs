﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENListaDeseos
    {
        private int _id_lista_deseo;
        private int _id_usuario;
        private int _id_juego;

        public int id_lista_deseo
        {
            get { return _id_lista_deseo; }
            set { _id_lista_deseo = value; }
        }
        public int id_usuario
        {
            get { return _id_usuario; }
            set { _id_usuario = value; }
        }
        public int id_juego
        {
            get { return _id_juego; }
            set { _id_juego = value; }
        }

        public ENListaDeseos()
        {

        }
        public ENListaDeseos(ENListaDeseos listaDeseos)
        {

        }
        public ENListaDeseos(int id_lista_deseos, int id_usuario, int id_juego)
        {

        }
        public bool create(ENListaDeseos listaDeseos)
        {
            return false;
        }
        public bool read(ENListaDeseos listaDeseos)
        {
            return false;
        }
        public bool update(ENListaDeseos listaDeseos)
        {
            return false;
        }
        public bool delete(ENListaDeseos listaDeseos)
        {
            return false;
        }
    }
}
