﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENFactura
    {
        private int _id_factura;
        private DateTime _fecha;
        private decimal _monto_total;
        private int _id_pedido;
        private int _id_usuario;

        public int id_factura
        {
            get { return _id_factura;}
            set { _id_factura=value;}
        }
        public DateTime fecha
        {
            get { return _fecha; }
            set { _fecha=value; }
        }
        public decimal monto_total
        {
            get { return _monto_total;}
            set { _monto_total=value;}
        }
        public int id_pedido
        {
            get { return _id_pedido;}
            set { _id_pedido=value;}
        }
        public int id_usuario
        {
            get { return _id_usuario; }
            set { _id_usuario=value; }
        }

        public ENFactura()
        {

        }

        public ENFactura(int factura_id, DateTime fecha, decimal total_monto, int pedido_id, int usuario_id)
        {
            _id_factura = factura_id;
            _fecha = fecha;
            _monto_total = total_monto;
            _id_pedido = pedido_id;
            _id_usuario = usuario_id;
        }

        public bool createFactura() 
        { 
            CADFactura cadFactura = new CADFactura();
            return cadFactura.createFactura(this);
        }

        public bool readFactura()
        {
            CADFactura cadFactura = new CADFactura();
            return cadFactura.readFactura(this);
        }

        public bool readFacturaPorPedido()
        {
            CADFactura cadFactura = new CADFactura();
            return cadFactura.readFacturaPorPedido(this);
        }
    }

   
}
