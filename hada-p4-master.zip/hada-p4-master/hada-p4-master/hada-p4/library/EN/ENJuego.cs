﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENJuego
    {
        private int _id_juego;
        private string _titulo;
        private DateTime _fecha;
        private string _descripcion;
        private decimal _precio;
        private int _categoria;
        private string _imagen;
        private string _desarrollador;
        private string _nombre_categoria;

        public int id_juego
        {
            get { return _id_juego; }
            set { _id_juego = value; }
        }
        public string titulo
        {
            get { return _titulo; }
            set { _titulo = value; }
        }
        public DateTime fecha
        {
            get { return _fecha; }
            set { _fecha = value; }
        }

        public string descripcion
        {
            get { return _descripcion; }
            set { _descripcion = value; }
        }
        public decimal precio
        {
            get { return _precio; }
            set { _precio = value; }
        }
        public int categoria
        {
            get { return _categoria; }
            set { _categoria = value; }
        }

        public string imagen
        {
            get { return _imagen; }
            set { _imagen = value; }
        }

        public string desarrollador
        {
            get { return _desarrollador; }
            set { _desarrollador = value; }
        }

        public string nombre_categoria
        {
            get { return _nombre_categoria; }
            set { _nombre_categoria = value; }
        }

        public ENJuego()
        {
            
        }

        
        public ENJuego(ENJuego juego)
        {
            this.id_juego = juego.id_juego;
            this.titulo = juego.titulo;
            this.fecha = juego.fecha;
            this.descripcion = juego.descripcion;
            this.precio = juego.precio;
            this.categoria = juego.categoria;
            this.imagen = juego.imagen;
            this.desarrollador = juego.desarrollador;
            this.nombre_categoria = juego.nombre_categoria;
        }

        //Solución táctica para AdminJuegos que no tiene en nombre_categoría
        public ENJuego(int id_juego, string titulo, DateTime fecha, string descripcion, decimal precio, int categoria, string imagen, string desarrollador)
        {
            this.id_juego = id_juego;
            this.titulo = titulo;
            this.fecha = fecha;
            this.descripcion = descripcion;
            this.precio = precio;
            this.categoria = categoria;
            this.imagen = imagen;
            this.desarrollador = desarrollador;
        }

        //Crea nombre categoria pero no lo declara???( en linea 111)
        public ENJuego(int id_juego, string titulo, DateTime fecha,string descripcion, decimal precio, int categoria, string imagen, string desarrollador, string nombre_categoria)
        {
            this.id_juego = id_juego;
            this.titulo = titulo;
            this.fecha = fecha;
            this.descripcion = descripcion;
            this.precio = precio;
            this.categoria = categoria;
            this.imagen = imagen;
            this.desarrollador = desarrollador;
            this.nombre_categoria = nombre_categoria;
        }

        public bool CreateJuego()
        {
            bool creado = false;
            CADJuego Juego = new CADJuego();
            creado = Juego.CreateJuego(this);
            return creado;
        }

        public bool CreateNuevoJuego()
        {
            CADJuego Juego = new CADJuego();
            return Juego.CreateNuevoJuego(this);
        }
        public bool ReadJuego()
        {
            bool read;
            CADJuego Juego = new CADJuego();
            read = Juego.ReadJuego(this);
            return read;
        }
        public bool UpdateJuego()
        {
            CADJuego CADJuego = new CADJuego();
            return CADJuego.UpdateJuego(this);
        }
        public bool DeleteJuego()
        {
            bool borrado = false;
            CADJuego Juego = new CADJuego();
            if ((Juego.ReadJuego(this)))
            {
                borrado = Juego.DeleteJuego(this);
            }

            return borrado;
        }
        public bool UpdateNuevoJuego()
        {
            CADJuego Juego = new CADJuego();
            return Juego.UpdateNuevoJuego(this);
        }
        public List<ENJuego> ObtenerJuegosFiltrados(string orden, string busqueda, List<int> categorias, Tuple<decimal?, decimal?> rangoPrecio)
        {
            return CADJuego.ObtenerJuegosFiltrados(orden, busqueda, categorias, rangoPrecio);
        }
        public List<ENJuego> ObtenerTodosLosJuegos()
        {
            return CADJuego.ObtenerTodosLosJuegos();
        }
        public ENJuego ObtenerJuegoPorId(int id)
        {
            return CADJuego.ObtenerJuegoPorId(id);
        }
        /*
        public List<ENJuego> BuscarJuegos(string busqueda)
        {
            return CADJuego.BuscarJuegos(busqueda);
        }
        */
    }
}
