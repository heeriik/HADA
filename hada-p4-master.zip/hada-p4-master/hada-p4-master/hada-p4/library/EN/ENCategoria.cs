﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENCategoria
    {

        private int _id_categoria;
        private string _nombre_categoria;

        public int id_categoria
        {
            get { return _id_categoria; }
            set { _id_categoria = value; }
        }
        public string nombre_categoria
        {
            get { return _nombre_categoria; }
            set { _nombre_categoria = value; }
        }

        public ENCategoria()
        {
            id_categoria = -1;
            nombre_categoria = "";
        }

        public ENCategoria(ENCategoria categoria)
        {
            this.id_categoria = categoria.id_categoria;
            this.nombre_categoria = categoria.nombre_categoria;

        }

        public ENCategoria(int id_categoria,string nombre_categoria)
        {
            this.id_categoria = id_categoria;
            this.nombre_categoria = nombre_categoria;
        }

        public bool CreateCategoria()
        {
            bool creado = false;
            CADCategoria categoria = new CADCategoria();
            creado = categoria.CreateCategoria(this);
            return creado;
        }

        public bool ReadCategoria()
        {
            bool leido = false;
            CADCategoria categoria = new CADCategoria();
            leido = categoria.ReadCategoria(this);
            return leido;
        }

        public string UpdateCategoria()
        {
            string updated = "";
            ENCategoria aux = new ENCategoria(this);
            CADCategoria categoria = new CADCategoria();
            if ((categoria.ReadCategoria(aux)))
            {
                updated = categoria.UpdateCategoria(this);
            }

            return updated;
        }

        public bool DeleteCategoria()
        {
            bool borrado = false;
            CADCategoria categoria = new CADCategoria();

            if (categoria.ReadCategoria(this))
                borrado = categoria.DeleteCategoria(this);

            return borrado;
        }

        public List<ENCategoria> ObtenerCategorias()
        {
            return CADCategoria.ObtenerCategorias();
        }

        public string ObtenerNombreCategoriaPorId(int idCategoria)
        {
            return CADCategoria.ObtenerNombreCategoriaPorId(idCategoria);
        }
    }
}
