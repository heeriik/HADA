﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENLinPedido
    {
        private int _id_lin_pedido;
        private int _id_pedido;
        private int _id_juego;
        private decimal _importe;


        public int id_lin_pedido
        {
            get { return _id_lin_pedido; }
            set { _id_lin_pedido = value; }
        }
        public int id_pedido
        {
            get { return _id_pedido; }
            set { _id_pedido = value; }
        }
        public int id_juego
        {
            get { return _id_juego; }
            set { _id_juego = value; }
        }

        public decimal importe
        {
            get { return _importe; }
            set { _importe = value; }
        }

        public ENLinPedido()
        {
            _id_lin_pedido = 0;
            _id_pedido = 0;
            _id_juego = 0;
            _importe = 0;
        }

        public ENLinPedido(int id_lin_pedido, int id_pedido, int id_juego, int cantidad, decimal importe)
        {
            _id_lin_pedido = id_lin_pedido;
            _id_pedido = id_pedido;
            _id_juego = id_juego;
            _importe = importe;

        }
        
        public bool Create(ENLinPedido linPedido)
        {
            CADLinPedido cad = new CADLinPedido();
            return cad.Create(this);
        }

        public bool Read(ENLinPedido linPedido)
        {
            CADLinPedido cad = new CADLinPedido();
            return cad.Read(this);
        }

        public bool Delete(ENLinPedido linPedido)
        {
            CADLinPedido cad = new CADLinPedido();
            return cad.Delete(this);
        }
    }
}
