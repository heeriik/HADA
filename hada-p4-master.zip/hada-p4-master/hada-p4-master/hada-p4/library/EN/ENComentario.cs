﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENComentario
    {
        private int _id_comentario;
        private int _valoracion;
        private string _contenido;
        private DateTime _fecha;
        private int _id_usuario;
        private int _id_juego;


        public int id_comentario
        {
            get { return _id_comentario; }
            set { _id_comentario = value; }
        }
        public int valoracion
        {
            get { return _valoracion; }
            set { _valoracion = value; }
        }
        public string contenido
        {
            get { return _contenido; }
            set { _contenido = value; }
        }
        public DateTime fecha
        {
            get { return _fecha; }
            set { _fecha = value; }
        }
        public int id_usuario
        {
            get { return _id_usuario; }
            set { _id_usuario = value; }
        }
        public int id_juego
        {
            get { return _id_juego; }
            set { _id_juego = value; }
        }


        public ENComentario()
        {
            id_comentario = -1;
            valoracion = -1;
            contenido = "";
            fecha = new DateTime(1990, 01, 01);
            id_usuario = -1;
            id_juego = -1;
        }

        public ENComentario(ENComentario comentario)
        {
            this.id_comentario = comentario.id_comentario;
            this.valoracion = comentario.valoracion;
            this.contenido = comentario.contenido;
            this.fecha = comentario.fecha;
            this.id_usuario = comentario.id_usuario;
            this.id_juego = comentario.id_juego;
        }

        public ENComentario(int id_comentario, int valoracion, string contenido, DateTime fecha, int id_usuario, int id_juego)
        {
            this._id_comentario = id_comentario;
            this._valoracion = valoracion;
            this._contenido = contenido;
            this._fecha = fecha;
            this._id_usuario = id_usuario;
            this._id_juego = id_juego; 
        }

        public bool CreateComentario()
        {
            bool creado = false;
            CADComentario Comentario = new CADComentario();
            creado = Comentario.CreateComentario(this);
            return creado;
        }

        public bool ReadComentario()
        {
            bool leido = false;
            CADComentario Comentario = new CADComentario();
            leido = Comentario.ReadComentario(this);
            return leido;
        }

        public string UpdateComentario()
        {
            string updated = "";
            ENComentario aux = new ENComentario(this);
            CADComentario Comentario = new CADComentario();
            if ((Comentario.ReadComentario(aux)))
            {
                updated = Comentario.UpdateComentario(this);
            }

            return updated;
        }

        public bool DeleteComentario()
        {
            bool borrado = false;
            CADComentario Comentario = new CADComentario();

            if (Comentario.ReadComentario(this))
                borrado = Comentario.DeleteComentario(this);

            return borrado;
        }
    }
}
