﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENPedido
    {
        private int _id_pedido;
        private int _id_usuario;
        private DateTime _fecha;
        private string _estado;

        public int id_pedido
        {
            get { return _id_pedido; }
            set { _id_pedido = value; }
        }
        public int id_usuario
        {
            get { return _id_usuario; }
            set { _id_usuario = value; }
        }
        public DateTime fecha
        {
            get { return _fecha; }
            set { _fecha = value; }
        }
        public string estado
        {
            get { return _estado; }
            set { _estado = value; }
        }

        public ENPedido()
        {

        }

        public ENPedido(int id_pedido, int id_usuario, DateTime fecha, string estado)
        {
            _id_pedido = id_pedido;
            _id_usuario = id_usuario;
            _fecha = fecha;
            _estado = estado;
        }

        public ENPedido(int id_usuario, DateTime fecha, string estado)
        {
            this.id_usuario = id_usuario;
            this.fecha = fecha;
            this.estado = estado;
        }

        public ENPedido(int id_usuario, int id_pedido)
        {
            this.id_usuario = id_usuario;
            this.id_pedido = id_pedido;
        }

        public bool Create(ENPedido pedido)
        {
            CADPedido cadPedido = new CADPedido();
            return cadPedido.Create(pedido);
        }
        public bool Read(ENPedido pedido)
        {
            CADPedido cadPedido = new CADPedido();
            return cadPedido.Read(pedido);
        }
        public bool Delete(ENPedido pedido)
        {
            CADPedido cadPedido = new CADPedido();
            return cadPedido.Delete(pedido);
        }

    }
}