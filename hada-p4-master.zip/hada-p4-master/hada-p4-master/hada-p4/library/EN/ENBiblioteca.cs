﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class ENBiblioteca
    {
        private int _id_biblio;
        private int _id_usuario;
        private int _id_juego;

        public int id_biblio
        {
            get { return _id_biblio; }
            set { _id_biblio = value; }
        }
        public int id_usuario
        {
            get { return _id_usuario; }
            set { _id_usuario = value; }
        }
        public int id_juego
        {
            get { return _id_juego; }
            set { _id_juego = value; }
        }

        public ENBiblioteca()
        {

        }
        public ENBiblioteca(int id, int id_usuario, int id_juego)
        {
            this.id_biblio = id;
            this.id_usuario = id_usuario;
            this.id_juego = id_juego;
        }  
    }
}
