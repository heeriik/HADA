﻿using library;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlTypes;
using System.Data;
using System.Data.Common;
using System.Net.Mail;
using System.Net;


namespace library
{
    public class CADFactura
    {
        private string constring;

        public CADFactura()
        {
            constring = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
        }
        
        public bool createFactura(ENFactura factura)
        {
            using (SqlConnection connection = new SqlConnection(constring))
            {
                string query = "INSERT INTO Factura (fecha, monto_total, id_pedido, id_usuario) VALUES (@fecha, @monto_total, @id_pedido, @id_usuario); SELECT SCOPE_IDENTITY();";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@fecha", factura.fecha);
                command.Parameters.AddWithValue("@monto_total", factura.monto_total);
                command.Parameters.AddWithValue("@id_pedido", factura.id_pedido);
                command.Parameters.AddWithValue("@id_usuario", factura.id_usuario);

                try
                {
                    connection.Open();
                    int idFactura = Convert.ToInt32(command.ExecuteScalar());
                    factura.id_factura = idFactura;
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error creating factura: " + ex.Message);
                    return false;
                }
            }
        }
        
        public bool readFactura(ENFactura factura)
        {
            using (SqlConnection connection = new SqlConnection(constring))
            {
                string query = "SELECT * FROM Factura WHERE id_factura = @id_factura";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id_factura", factura.id_factura);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        factura.fecha = reader.GetDateTime(reader.GetOrdinal("fecha"));
                        factura.monto_total = reader.GetDecimal(reader.GetOrdinal("monto_total"));
                        factura.id_pedido = reader.GetInt32(reader.GetOrdinal("id_pedido"));
                        factura.id_usuario = reader.GetInt32(reader.GetOrdinal("id_usuario"));
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }
        

        public bool realizarFactura(int id_usuario)
        {
            try
            {
                // 1. Obtener el carrito del usuario
                ENPedido pedido = ObtenerPedidoPorUsuario(id_usuario);

                // 2. Obtener las líneas de pedido asociadas a la factura
                List<ENLinPedido> lineasPedido = ObtenerLineasFacturaPorPedido(pedido.id_pedido);

                List<int> juegosEnPedido = new List<int>();

                // 3. Crear un nuevo pedido
                ENFactura nuevaFactura = new ENFactura
                {
                    fecha = DateTime.Now,
                    monto_total = CalcularMontoTotal(ObtenerJuegosEnPedido(pedido.id_pedido)),
                    id_pedido = pedido.id_pedido,
                    id_usuario = id_usuario,
                
                };
                int id_factura = InsertarFactura(nuevaFactura);

                // 4. Asociar las líneas de pedido al pedido creado
                foreach (ENLinPedido linea in lineasPedido)
                {
                    ENLinFactura aux = new ENLinFactura
                    {
                        precio_unitario = ObtenerPrecioJuego(linea.id_juego),
                        id_factura = id_factura,
                        id_juego = linea.id_juego
                    };
                    // Insertar la línea de pedido asociada al nuevo pedido
                    InsertarLineaFactura
                    (
                        aux
                    );
                }

                // 5. Enviar la factura por correo
                string correoUsuario = ObtenerCorreoUsuario(id_usuario);

                EnviarCorreoFactura(correoUsuario, nuevaFactura, pedido.id_pedido);

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                return false;
            }
        }



        public ENPedido ObtenerPedidoPorUsuario(int id_usuario)
        {
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "SELECT * FROM Pedido WHERE id_usuario = @id_usuario ORDER BY id_pedido DESC";
                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@id_usuario", id_usuario);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    int id_pedido = reader.GetInt32(0);
                    
                    return new ENPedido(id_usuario, id_pedido);
                }
                throw new Exception("No se encontró un pedido para el usuario especificado.");
            }
        }

        public List<ENLinPedido> ObtenerLineasFacturaPorPedido(int id_pedido)
        {
            List<ENLinPedido> lineasPedido = new List<ENLinPedido>();

            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    con.Open();
                    string query = "SELECT id_lin_pedido, id_pedido, importe, id_juego FROM LinPedido WHERE id_pedido = @id_pedido";
                     SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@id_pedido", id_pedido);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        ENLinPedido aux = new ENLinPedido
                        {
                            id_lin_pedido = reader.GetInt32(0),
                            id_pedido = reader.GetInt32(1),
                            importe = reader.GetDecimal(2),
                            id_juego = reader.GetInt32(3)
                        };
                        lineasPedido.Add(aux);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error al obtener las líneas de factura por pedido: " + ex.Message);
            }
            return lineasPedido;
        }

        public int InsertarFactura(ENFactura factura)
        {
            int idFactura = 0;

            string query = @"
                INSERT INTO Factura (fecha, monto_total, id_pedido, id_usuario)
                VALUES (@fecha, @monto_total, @id_pedido, @id_usuario);
                SELECT SCOPE_IDENTITY();";  // Obtiene el último ID insertado

            using (SqlConnection connection = new SqlConnection(constring))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@fecha", factura.fecha);
                    command.Parameters.AddWithValue("@monto_total", factura.monto_total);
                    command.Parameters.AddWithValue("@id_pedido", factura.id_pedido);
                    command.Parameters.AddWithValue("@id_usuario", factura.id_usuario);

                    connection.Open();
                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        idFactura = Convert.ToInt32(result);
                    }
                }
            }

            return idFactura;
        }

        public decimal ObtenerPrecioJuego(int id_juego)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    con.Open();
                    string query = "SELECT precio FROM Juego WHERE id_juego = @id_juego";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@id_juego", id_juego);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        return reader.GetDecimal(0);
                    }
                }
            }
            catch (Exception ex)
            {

                Debug.WriteLine("Error: " + ex.Message);

            }
            return -1;
        }

        //Arreglado el error de la query - Erik
        public void InsertarLineaFactura(ENLinFactura linea)
        {
            string query = @"
                INSERT INTO LinFactura (precio_unitario, id_juego, id_factura)
                VALUES (@precio_unitario, @id_juego, @id_factura);";

            using (SqlConnection connection = new SqlConnection(constring))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@precio_unitario", linea.precio_unitario);
                    command.Parameters.AddWithValue("@id_juego", linea.id_juego);
                    command.Parameters.AddWithValue("@id_factura", linea.id_factura);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private decimal CalcularMontoTotal(List<int> juegosEnPedido)
        {
            decimal total = 0;
            CADJuego cadJuego = new CADJuego();

            foreach (int juegoId in juegosEnPedido)
            {
                ENJuego juego = new ENJuego { id_juego = juegoId };

                if (cadJuego.ReadJuego(juego))
                {
                    total += juego.precio; // Cantidad siempre 1, así que solo sumamos el precio unitario
                }
            }

            return total;
        }

        public List<int> ObtenerJuegosEnPedido(int idPedido)
        {
            List<int> juegosEnPedido = new List<int>();

            using (SqlConnection conn = new SqlConnection(constring))
            {
                string query = "SELECT id_juego FROM LinPedido WHERE id_pedido = @idPedido";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@idPedido", idPedido);

                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        juegosEnPedido.Add(reader.GetInt32(0));
                    }
                }
                catch (SqlException ex)
                {
                    // Manejo de excepciones
                    throw new Exception("Error al obtener los juegos del pedido", ex);
                }
            }

            return juegosEnPedido;
        }

        public bool readFacturaPorPedido(ENFactura factura)
        {
            using (SqlConnection connection = new SqlConnection(constring))
            {
                string query = "SELECT * FROM Factura WHERE id_pedido = @id_pedido";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id_pedido", factura.id_pedido);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        factura.fecha = reader.GetDateTime(reader.GetOrdinal("fecha"));
                        factura.monto_total = reader.GetDecimal(reader.GetOrdinal("monto_total"));
                        factura.id_pedido = reader.GetInt32(reader.GetOrdinal("id_pedido"));
                        factura.id_usuario = reader.GetInt32(reader.GetOrdinal("id_usuario"));
                        factura.id_factura = reader.GetInt32(reader.GetOrdinal("id_factura"));
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        //Función para obtener el correo del usuario - Erik
        private string ObtenerCorreoUsuario(int id_usuario)
        {
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "SELECT correo FROM Usuario WHERE id_usuario = @id_usuario";
                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@id_usuario", id_usuario);
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    return result.ToString();
                }
                else
                {
                    throw new Exception("No se encontró un correo electrónico para el usuario especificado.");
                }
            }
        }

        private void EnviarCorreoFactura(string email_destino, ENFactura factura, int id_pedido)
        {
            string email_name = "stealhada2024@gmail.com";
            string password = "disjxggodhvwqmuu";
            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(email_name);
            mail.To.Add(email_destino);
            mail.Subject = "Factura de tu compra";
            List<ENLinPedido> lineasPedido = ObtenerLineasFacturaPorPedido(id_pedido);
            mail.Body = GenerarCuerpoCorreo(factura, lineasPedido);

            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
            smtpClient.Credentials = new NetworkCredential(email_name, password);
            smtpClient.EnableSsl = true;

            try
            {
                smtpClient.Send(mail);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al enviar el correo: " + ex.Message);
            }
        }

        private string GenerarCuerpoCorreo(ENFactura factura, List<ENLinPedido> lineasPedido)
        {
            StringBuilder body = new StringBuilder();
            body.AppendLine("Gracias por tu compra!");
            body.AppendLine("Detalles de la factura:");
            body.AppendLine($"Fecha: {factura.fecha}");
            body.AppendLine($"Monto Total: {factura.monto_total}");
            body.AppendLine("Items:");

            // Añadir cada juego al cuerpo del correo - método auxiliar
            for (int i = 0; i < lineasPedido.Count ; i++)
            {
                ENLinPedido linea = lineasPedido[i];
                int numeroJuego = i + 1;
                string nombre_juego = ObtenerNombreJuego(linea.id_juego);
                body.AppendLine($"- Juego {numeroJuego}: {nombre_juego}, Importe: {linea.importe}");

            }

            return body.ToString();
        }

        private string ObtenerNombreJuego(int id_juego)
        {
            string nombreJuego = string.Empty;

            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    con.Open();
                    string query = "SELECT titulo FROM Juego WHERE id_juego = @id_juego";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@id_juego", id_juego);
                    nombreJuego = command.ExecuteScalar()?.ToString();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener el nombre del juego: " + ex.Message);
            }

            return nombreJuego;
        }

    }


}
