﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class CADListaDeseos
    {
        public CADListaDeseos()
        {

        }

        public bool create(ENListaDeseos listaDeseos)
        {
            return false;
        }
        public bool read(ENListaDeseos listaDeseos)
        {
            return false;
        }
        public bool update(ENListaDeseos listaDeseos)
        {
            return false;
        }
        public bool delete(ENListaDeseos listaDeseos)
        {
            return false;
        }
    }
}
