﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class CADUsuario
    {
        private static string _constring;
        private static string constring
        {
            get
            {
                if (_constring == null)
                {
                    return ConfigurationManager.ConnectionStrings["Database"].ToString();
                }
                else
                {
                    return _constring;
                }
            }
            set
            {
                if (value == null)
                {
                    _constring = ConfigurationManager.ConnectionStrings["Database"].ToString();
                }
                else
                {
                    _constring = value;
                }
            }
        }

        public CADUsuario()
        {
            
        }

        public static bool create(ENUsuario usuario)
        {
            bool creado = false;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "INSERT INTO USUARIO (nombre_usuario, correo, contrasena) VALUES (@nombre, @correo, @contraseña)";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@nombre", usuario.nombre_usuario);
                command.Parameters.AddWithValue("@correo", usuario.correo);
                command.Parameters.AddWithValue("@contraseña", usuario.contrasena);


                int filasAfectadas = (int)command.ExecuteNonQuery();

                if (filasAfectadas > 0)
                {
                    creado = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al crear el usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return creado;
        }
        public static bool read(ENUsuario usuario)
        {
            return false;
        }
        public static bool update(ENUsuario usuario)
        {
            bool actualizado = false;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "UPDATE Usuario SET nombre_usuario = @nombre, correo = @correo" +
                                  (!string.IsNullOrEmpty(usuario.contrasena) ? ", contrasena = @contraseña" : "") +
                                  " WHERE id_usuario = @id";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@id", usuario.id_usuario);
                command.Parameters.AddWithValue("@nombre", usuario.nombre_usuario);
                command.Parameters.AddWithValue("@correo", usuario.correo);
                
                if (!string.IsNullOrEmpty(usuario.contrasena))
                {
                    command.Parameters.AddWithValue("@contraseña", usuario.contrasena);
                }

                int filasAfectadas = command.ExecuteNonQuery();

                if (filasAfectadas > 0)
                {
                    actualizado = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al actualizar el usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return actualizado;
        }
        public static bool delete(ENUsuario usuario)
        {
            bool eliminado = false;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "DELETE FROM Usuario WHERE id_usuario = @id";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@id", usuario.id_usuario);

                int filasAfectadas = (int)command.ExecuteNonQuery();

                if (filasAfectadas > 0)
                {
                    eliminado = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al eliminar el usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return eliminado;
        }
        public static bool ValidarCredenciales(string correo, string contraseña)
        {
            bool existe = false;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "SELECT COUNT(*) FROM Usuario WHERE correo = @Correo AND contrasena = @Contraseña";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@Correo", correo);
                command.Parameters.AddWithValue("@Contraseña", contraseña);

                int count = (int)command.ExecuteScalar();

                if(count > 0)
                {
                    existe = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al validar las credenciales: " + ex.Message);
            }
            finally
            {
                if(connection != null)
                {
                    connection.Close();
                }
            }
            return existe;
        }
        public static int ObtenerIdUsuario(string correo)
        {
            int id = -1;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "SELECT id_usuario FROM Usuario WHERE correo = @Correo";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@Correo", correo);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    id = Convert.ToInt32(reader["id_usuario"]);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener el Id del usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return id;
        }
        public static bool ExisteCorreo(string correo)
        {
            bool existe = false;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "SELECT COUNT(*) FROM Usuario WHERE correo = @Correo";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@Correo", correo);

                int count = (int)command.ExecuteScalar();

                if (count > 0)
                {
                    existe = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al verificar el correo: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return existe;
        }
        public static ENUsuario ObtenerUsuarioPorId(int id)
        {
            ENUsuario usuario = null;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "SELECT id_usuario, nombre_usuario, correo, contrasena, saldo_disponible FROM Usuario WHERE id_usuario = @Id";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@Id", id);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    usuario = new ENUsuario();
                    usuario.id_usuario = Convert.ToInt32(reader["id_usuario"]);
                    usuario.nombre_usuario = reader["nombre_usuario"].ToString();
                    usuario.correo = reader["correo"].ToString();
                    usuario.contrasena = reader["contrasena"].ToString();
                    usuario.saldo_disponible = Convert.ToDecimal(reader["saldo_disponible"]);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener el Id del usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return usuario;
        }
        public static List<ENUsuario> ObtenerUsuarios()
        {
            List<ENUsuario> usuarios = new List<ENUsuario>();
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "SELECT id_usuario, nombre_usuario, correo FROM Usuario";

                SqlCommand command = new SqlCommand(consulta, connection);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ENUsuario usuario = new ENUsuario();
                    usuario.id_usuario = Convert.ToInt32(reader["id_usuario"]);
                    usuario.nombre_usuario = reader["nombre_usuario"].ToString();
                    usuario.correo = reader["correo"].ToString();

                    usuarios.Add(usuario);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener el Id del usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return usuarios;
        }
        public static bool ActualizarUsuario(ENUsuario usuario)
        {
            bool actualizado = false;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "UPDATE Usuario SET nombre_usuario = @nombre, correo = @correo WHERE id_usuario = @id";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@id", usuario.id_usuario);
                command.Parameters.AddWithValue("@nombre", usuario.nombre_usuario);
                command.Parameters.AddWithValue("@correo", usuario.correo);

                int filasAfectadas = (int)command.ExecuteNonQuery();

                if (filasAfectadas > 0)
                {
                    actualizado = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al actualizar el usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return actualizado;
        }
        public static bool AgregarImporte(int id, decimal importe)
        {
            bool agregado = false;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                ENUsuario usuario = new ENUsuario();
                usuario = ObtenerUsuarioPorId(id);

                importe += usuario.saldo_disponible;

                connection.Open();

                string consulta = "UPDATE Usuario SET saldo_disponible = @saldo WHERE id_usuario = @id";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@id", id);
                command.Parameters.AddWithValue("@saldo", importe);

                int filasAfectadas = (int)command.ExecuteNonQuery();

                if (filasAfectadas > 0)
                {
                    agregado = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al actualizar el usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return agregado;
        }
    }
}
