﻿using library;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace library
{
    public class CADLinFactura
    {
        private string constring;

        public CADLinFactura()
        {
            constring = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
        }

        public bool createLinFactura(ENLinFactura linFactura)
        {
            using (SqlConnection connection = new SqlConnection(constring))
            {
                

                try
                {
                    connection.Open();
                    string query = "INSERT INTO LinFactura (id_factura, id_juego, precio_unitario) " +
                                   "VALUES (@id_factura, @id_juego, @precio_unitario)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_factura", linFactura.id_factura);
                    command.Parameters.AddWithValue("@id_juego", linFactura.id_juego);
                    command.Parameters.AddWithValue("@precio_unitario", linFactura.precio_unitario);
                    command.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public bool readLinFactura(ENLinFactura linFactura)
        {
            using (SqlConnection connection = new SqlConnection(constring))
            {
                string query = "SELECT * FROM LinFactura WHERE id_lin_factura = @id_lin_factura";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id_lin_factura", linFactura.id_lin_factura);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        linFactura.id_factura = reader.GetInt32(reader.GetOrdinal("id_factura"));
                        linFactura.id_juego = reader.GetInt32(reader.GetOrdinal("id_juego"));
                        linFactura.precio_unitario = reader.GetDecimal(reader.GetOrdinal("precio_unitario"));
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }


        

        
    }

}