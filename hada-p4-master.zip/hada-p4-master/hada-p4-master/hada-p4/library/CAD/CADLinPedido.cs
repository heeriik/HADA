﻿using library;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class CADLinPedido
    {
        private string constring;

        public CADLinPedido()
        {
            constring = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
        }

        public bool Create(ENLinPedido linpedido)
        {
            SqlConnection con = new SqlConnection(constring);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("INSERT INTO lin_pedido (id_pedido, id_juego, importe) VALUES (@id_pedido, @id_juego, @importe)", con);
                command.Parameters.AddWithValue("@id_pedido", linpedido.id_pedido);
                command.Parameters.AddWithValue("@id_juego", linpedido.id_juego);
                command.Parameters.AddWithValue("@importe", linpedido.importe);
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }

        public bool Read(ENLinPedido linpedido)
        {
            SqlConnection con = new SqlConnection(constring);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("SELECT * FROM lin_pedido WHERE id_lin_pedido = @id_lin_pedido", con);
                command.Parameters.AddWithValue("@id_lin_pedido", linpedido.id_lin_pedido);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    linpedido.id_pedido = reader.GetInt32(1);
                    linpedido.id_juego = reader.GetInt32(2);
                    linpedido.importe = reader.GetDecimal(3);
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }

        public bool Delete(ENLinPedido linpedido)
        {
            SqlConnection con = new SqlConnection(constring);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("DELETE FROM lin_pedido WHERE id_lin_pedido = @id_lin_pedido", con);
                command.Parameters.AddWithValue("@id_lin_pedido", linpedido.id_lin_pedido);
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }

    }
}
