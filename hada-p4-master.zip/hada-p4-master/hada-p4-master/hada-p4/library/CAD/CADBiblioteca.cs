﻿using library;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class CADBiblioteca
    {
        private string constring;
        public CADBiblioteca()
        {
            constring = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
        }


        public List<int> ObtenerJuegosEnBibliotecaPorUsuario(int idUsuario)
        {
            List<int> juegosEnBiblioteca = new List<int>();

            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    con.Open();
                    string query = "SELECT id_juego FROM Biblioteca WHERE id_usuario = @idUsuario";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@idUsuario", idUsuario);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            juegosEnBiblioteca.Add(reader.GetInt32(0));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener los juegos en la biblioteca del usuario: " + ex.Message);
            }

            return juegosEnBiblioteca;
        }

        public ENJuego ObtenerJuegosBD(int idJuego)
        {
            ENJuego juego = null;

            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    con.Open();
                    string query = "SELECT * FROM Juego WHERE id_juego = @idJuego";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@idJuego", idJuego);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            juego = new ENJuego
                            {
                                id_juego = reader.GetInt32(0),
                                titulo = reader.GetString(1),
                                fecha = reader.GetDateTime(2),
                                descripcion = reader.GetString(3),
                                precio = reader.GetDecimal(4),
                                imagen = reader.GetString(5),
                                desarrollador = reader.GetString(6),
                                categoria = reader.GetInt32(7)
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener los detalles del juego: " + ex.Message);
            }

            return juego;
        }

        public List<ENJuego> ObtenerJuegosPorCategoria(int idCategoria)
        {
            List<ENJuego> juegos = new List<ENJuego>();

            string connectionString = "tu_cadena_de_conexión"; // Reemplaza esto con tu cadena de conexión real
            string query = "SELECT * FROM Juego WHERE categoria = @idCategoria";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@idCategoria", idCategoria);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ENJuego juego = new ENJuego();
                            juego.id_juego = Convert.ToInt32(reader["id_juego"]);
                            juego.titulo = Convert.ToString(reader["titulo"]);
                            // Agrega más propiedades según sea necesario

                            juegos.Add(juego);
                        }
                    }
                }
            }

            return juegos;
        }
        private int ObtenerIdCategoria(string terminoBusqueda)
        {
            int idCategoria = -1; // Valor por defecto si no se encuentra ninguna categoría

            string connectionString = "tu_cadena_de_conexión"; // Reemplaza esto con tu cadena de conexión real
            string query = "SELECT id_categoria FROM Categoria WHERE nombre_categoria LIKE @terminoBusqueda";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@terminoBusqueda", "%" + terminoBusqueda + "%");

                    connection.Open();

                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        idCategoria = Convert.ToInt32(result);
                    }
                }
            }

            return idCategoria;
        }

        public void AgregarJuegoABiblioteca(int idUsuario, int idJuego)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    con.Open();
                    string query = "INSERT INTO Biblioteca (id_usuario, id_juego) VALUES (@idUsuario, @idJuego)";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@idUsuario", idUsuario);
                    command.Parameters.AddWithValue("@idJuego", idJuego);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al agregar el juego a la biblioteca: " + ex.Message);
            }
        }
    }
}
