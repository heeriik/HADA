﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using library;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
using System.Data;

namespace library
{
    public class CADCategoria
    {
        private static string _constring;
        private static string constring
        {
            get
            {
                if (_constring == null)
                {
                    return ConfigurationManager.ConnectionStrings["Database"].ToString();
                }
                else
                {
                    return _constring;
                }
            }
            set
            {
                if (value == null)
                {
                    _constring = ConfigurationManager.ConnectionStrings["Database"].ToString();
                }
                else
                {
                    _constring = value;
                }
            }
        }
        public CADCategoria()
        {
            
        }

        public bool CreateCategoria(ENCategoria categoria)
        {
            bool creado = false;

            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    conection.Open();
                    SqlCommand consulta = new SqlCommand("INSERT INTO [dbo].[Categoria] (nombre_categoria) VALUES (@nombre_categoria)", conection);

                    consulta.Parameters.AddWithValue("@nombre_categoria", categoria.nombre_categoria);

                    consulta.ExecuteNonQuery();
                    creado = true;
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("Error de SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error general: " + ex.Message);
                }
            }

            return creado;
        }

        public bool ReadCategoria(ENCategoria categoria)
        {
            bool leido = false;
            string consulta = "SELECT * FROM [dbo].[Categoria] WHERE id_categoria = @id_categoria";

            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    conection.Open();
                    SqlCommand select = new SqlCommand(consulta, conection);
                    select.Parameters.AddWithValue("@id_categoria", categoria.id_categoria);

                    using (SqlDataReader read = select.ExecuteReader())
                    {
                        if (read.Read())
                        {
                            categoria.nombre_categoria = read["nombre_categoria"].ToString();
                            leido = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return leido;
        }

        public string UpdateCategoria(ENCategoria categoria)
        {
            string resultado = "";

            try
            {
                using (SqlConnection conection = new SqlConnection(constring))
                {
                    conection.Open();

                    using (SqlCommand consulta = new SqlCommand("UPDATE [dbo].[Categoria] SET nombre_categoria = @nombre_categoria WHERE id_categoria = @id_categoria", conection))
                    {
                        consulta.Parameters.AddWithValue("@id_categoria", categoria.id_categoria);
                        consulta.Parameters.AddWithValue("@nombre_categoria", categoria.nombre_categoria);

                        int filasAfectadas = consulta.ExecuteNonQuery();

                        if (filasAfectadas > 0)
                        {
                            resultado = "Se ha actualizado correctamente";
                        }
                        else
                        {
                            resultado = "No se encontró el comentario para actualizar";
                        }
                    }
                }
            }
            catch (SqlException exce)
            {
                resultado = "Error de SQL: " + exce.Message;
                Console.WriteLine(resultado);
            }
            catch (Exception exc)
            {
                resultado = "Error general: " + exc.Message;
                Console.WriteLine(resultado);
            }

            return resultado;
        }

        public bool DeleteCategoria(ENCategoria categoria)
        {
            bool ok = false;

            try
            {
                using (SqlConnection conection = new SqlConnection(constring))
                {
                    conection.Open();
                    using (SqlCommand consulta = new SqlCommand("DELETE FROM [dbo].[Categoria] WHERE id_categoria = @id_categoria", conection))
                    {
                        consulta.Parameters.Add("@id_categoria", SqlDbType.Int).Value = categoria.id_categoria;
                        int rowsAffected = consulta.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            ok = true;
                        }
                    }
                }
            }
            catch (SqlException exce)
            {
                Console.WriteLine("Error de SQL: " + exce.Message);
            }
            catch (Exception exc)
            {
                Console.WriteLine("Error general: " + exc.Message);
            }

            return ok;
        }

        public static List<ENCategoria> ObtenerCategorias()
        {
            List<ENCategoria> categorias = new List<ENCategoria>();

            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();
                string consulta = "SELECT id_categoria, nombre_categoria FROM Categoria";

                SqlCommand command = new SqlCommand(consulta, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ENCategoria categoria = new ENCategoria();
                    categoria.id_categoria = Convert.ToInt32(reader["id_categoria"]);
                    categoria.nombre_categoria = reader["nombre_categoria"].ToString();

                    categorias.Add(categoria);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener las categorias: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return categorias;
        }

        public static string ObtenerNombreCategoriaPorId(int idCategoria)
        {
            string nombreCategoria = "";
            SqlConnection connection = new SqlConnection(constring);

            try
            { 
                connection.Open();

                string consulta = "SELECT nombre_categoria FROM Categoria WHERE id_categoria = @idCategoria";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@idCategoria", idCategoria);

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    nombreCategoria = reader["nombre_categoria"].ToString();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener el nombre de la categoría: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }

            return nombreCategoria;
        }
    }
}
