﻿using library;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class CADPedido
    {
        private string constring;

        public CADPedido()
        {
            constring = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
        }
        public bool Create(ENPedido pedido)
        {
            SqlConnection con = new SqlConnection(constring);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("INSERT INTO pedido (id_usuario, fecha, estado, direccion_envio) VALUES (@id_usuario, @fecha, @estado, @direccion_envio)", con);
                command.Parameters.AddWithValue("@id_usuario", pedido.id_usuario);
                command.Parameters.AddWithValue("@fecha", pedido.fecha);
                command.Parameters.AddWithValue("@estado", pedido.estado);
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        public bool Read(ENPedido pedido)
        {
            SqlConnection con = new SqlConnection(constring);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("SELECT * FROM pedido WHERE id_pedido = @id_pedido", con);
                command.Parameters.AddWithValue("@id_pedido", pedido.id_pedido);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    pedido.id_usuario = reader.GetInt32(1);
                    pedido.fecha = reader.GetDateTime(2);
                    pedido.estado = reader.GetString(3);
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        public bool Delete(ENPedido pedido)
        {
            SqlConnection con = new SqlConnection(constring);
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("DELETE FROM pedido WHERE id_pedido = @id_pedido", con);
                command.Parameters.AddWithValue("@id_pedido", pedido.id_pedido);
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        public ENCarrito ObtenerCarritoPorUsuario(int id_usuario)
        {
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "SELECT * FROM Carrito WHERE id_usuario = @id_usuario";
                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@id_usuario", id_usuario);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    int id_carrito = reader.GetInt32(0);
                    // Aquí podrías construir y retornar un objeto ENCarrito con los datos obtenidos
                    return new ENCarrito(id_usuario, id_carrito);
                }
                throw new Exception("No se encontró un carrito para el usuario especificado.");
            }
        }

        public List<ENLinCarrito> ObtenerLineasPedidoPorCarrito(int id_carrito)
        {
            List<ENLinCarrito> lineasCarrito = new List<ENLinCarrito>();
            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    con.Open();
                    string query = "SELECT * FROM LinCarrito WHERE id_carrito = @id_carrito";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@id_carrito", id_carrito);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        ENLinCarrito aux = new ENLinCarrito
                        {
                            id_linea = reader.GetInt32(0),
                            id_carrito = reader.GetInt32(1),
                            id_juego = reader.GetInt32(2)
                        };
                        lineasCarrito.Add(aux);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error al obtener las líneas de pedido por carrito: " + ex.Message);
            }

            return lineasCarrito;
        }
        public int InsertarPedido(ENPedido pedido)
        {
            int idPedido = 0;

            string query = @"
                INSERT INTO Pedido (fecha, estado, id_usuario)
                VALUES (@fecha, @estado, @id_usuario);
                SELECT SCOPE_IDENTITY();";  // Obtiene el último ID insertado

            using (SqlConnection connection = new SqlConnection(constring))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@fecha", pedido.fecha);
                    command.Parameters.AddWithValue("@estado", pedido.estado);
                    command.Parameters.AddWithValue("@id_usuario", pedido.id_usuario);

                    connection.Open();
                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        idPedido = Convert.ToInt32(result);
                    }
                }
            }

            return idPedido;
        }
        public decimal ObtenerPrecioJuego(int id_juego)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(constring))
                {
                    con.Open();
                    string query = "SELECT precio FROM Juego WHERE id_juego = @id_juego";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@id_juego", id_juego);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        return reader.GetDecimal(0);
                    }
                }
            }
            catch (Exception ex)
            {

                Debug.WriteLine("Error: " + ex.Message);

            }
            return -1;
        }
        public void InsertarLineaPedido(ENLinPedido linea)
        {
            string query = @"
                INSERT INTO LinPedido (id_pedido, id_juego, importe)
                VALUES (@id_pedido, @id_juego, @importe);";

            using (SqlConnection connection = new SqlConnection(constring))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id_pedido", linea.id_pedido);
                    command.Parameters.AddWithValue("@id_juego", linea.id_juego);
                    command.Parameters.AddWithValue("@importe", linea.importe);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        //Función que realiza la compra y principal función  de "Comprar" en la página web "Carrito.aspx"
        public bool RealizarCompra(int id_usuario)
        {
            try
            {
                // 1. Obtener el carrito del usuario
                ENCarrito carrito = ObtenerCarritoPorUsuario(id_usuario);

                // 2. Obtener las líneas de pedido asociadas al carrito
                List<ENLinCarrito> lineasCarrito = ObtenerLineasPedidoPorCarrito(carrito.id_carrito);

                // 3. Crear un nuevo pedido
                ENPedido nuevoPedido = new ENPedido
                {
                    id_usuario = id_usuario,
                    fecha = DateTime.Now,
                    estado = "Pendiente",
                };
                int id_pedido = InsertarPedido(nuevoPedido);

                // 4. Asociar las líneas de pedido al pedido creado
                foreach (ENLinCarrito linea in lineasCarrito)
                {
                    ENLinPedido aux = new ENLinPedido
                    {
                        importe = ObtenerPrecioJuego(linea.id_juego),
                        id_pedido = id_pedido,
                        id_juego = linea.id_juego
                    };
                    // Insertar la línea de pedido asociada al nuevo pedido
                    InsertarLineaPedido
                    (
                        aux
                    );
                    
                    // Agregar el juego a la biblioteca del usuario
                    new CADBiblioteca().AgregarJuegoABiblioteca(id_usuario, aux.id_juego);
                }

                // 5. Vaciar el carrito del usuario
                carrito.VaciarCarrito(id_usuario);

                // La compra se realizó con éxito
                return true;
            }
            catch (Exception ex)
            {

                // Ocurrió un error al realizar la compra
                Console.WriteLine("Error al realizar la compra: " + ex.Message);
                return false;
            }
        }


        
    }
}