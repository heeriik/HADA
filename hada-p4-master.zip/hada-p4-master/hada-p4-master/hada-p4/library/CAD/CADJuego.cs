﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using library;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
using System.Data;

namespace library
{
    public class CADJuego
    {
        private static string _constring;
        private static string constring
        {
            get
            {
                if (_constring == null)
                {
                    return ConfigurationManager.ConnectionStrings["Database"].ToString();
                }
                else
                {
                    return _constring;
                }
            }
            set
            {
                if (value == null)
                {
                    _constring = ConfigurationManager.ConnectionStrings["Database"].ToString();
                }
                else
                {
                    _constring = value;
                }
            }
        }

        public CADJuego()
        {

        }

        /*  public int ObtenerId()
          {
              int newId = 1;
              SqlConnection conection = new SqlConnection(constring);
              try
              {
                  conection.Open();
                  SqlCommand consulta = new SqlCommand("Select max(Id_juego) maxId, Count(Id_juego) numRows from [dbo].[Juego]", conection);

                  SqlDataReader dr = consulta.ExecuteReader();
                  dr.Read();

                  if (int.Parse(dr["numRows"].ToString()) != 0)
                  {
                      newId = int.Parse(dr["maxId"].ToString()) + 1;
                      dr.Close();
                  }
              }
              catch (Exception ex)
              {
                  Console.WriteLine(ex.Message);
              }
              finally
              {
                  conection.Close();
              }

              return newId;
          }*/

        //Solución táctica para AdminJuegos 
        public bool CreateNuevoJuego(ENJuego juego)
        {
            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    SqlConnection con = new SqlConnection(constring);
                    try
                    {
                        con.Open();
                        SqlCommand command = new SqlCommand("INSERT INTO pedido (titulo, fecha, descripcion, precio, categoria, imagen, desarrollador) VALUES (@titulo, @fecha, @descripcion, @precio, @categoria, @imagen, @desarrollador)", con);
                        command.Parameters.AddWithValue("@id_usuario", juego.titulo);
                        command.Parameters.AddWithValue("@fecha", juego.fecha);
                        command.Parameters.AddWithValue("@descripcion", juego.descripcion);
                        command.Parameters.AddWithValue("@precio", juego.precio);
                        command.Parameters.AddWithValue("@categoria", juego.categoria);
                        command.Parameters.AddWithValue("@imagen", juego.imagen);
                        command.Parameters.AddWithValue("@desarrollador", juego.desarrollador);
                        
                        command.ExecuteNonQuery();
                        return true;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                        return false;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al crear el juego: " + ex.Message);
                    return false;
                }
                finally
                {
                    conection.Close();
                }
            }

        }

        public bool UpdateNuevoJuego(ENJuego juego)
        {
            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    conection.Open();
                    SqlCommand command = new SqlCommand("UPDATE Juego SET titulo = @titulo, fecha = @fecha, descripcion = @descripcion, precio = @precio, categoria = @categoria, imagen = @imagen, desarrollador = @desarrollador WHERE id_juego = @id_juego", conection);
                    command.Parameters.AddWithValue("@titulo", juego.titulo);
                    command.Parameters.AddWithValue("@fecha", juego.fecha);
                    command.Parameters.AddWithValue("@descripcion", juego.descripcion);
                    command.Parameters.AddWithValue("@precio", juego.precio);
                    command.Parameters.AddWithValue("@categoria", juego.categoria);
                    command.Parameters.AddWithValue("@imagen", juego.imagen);
                    command.Parameters.AddWithValue("@desarrollador", juego.desarrollador);
                    command.Parameters.AddWithValue("@id_juego", juego.id_juego);

                    command.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al actualizar el juego: " + ex.Message);
                    return false;
                }
                finally
                {
                    conection.Close();
                }
            }   
        }

        public bool CreateJuego(ENJuego juego)
        {
            bool creado = false;

            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    conection.Open();

                    SqlCommand consulta = new SqlCommand(
                        "INSERT INTO [dbo].[Juego] (titulo, fecha, descripcion, precio, categoria, imagen, desarrollador) " +
                        "VALUES (@titulo, @fecha, @descripcion, @precio, @categoria, @imagen, @desarrollador)", conection);

                    consulta.Parameters.Add("@titulo", SqlDbType.VarChar, 255).Value = juego.titulo;
                    consulta.Parameters.Add("@fecha", SqlDbType.DateTime).Value = juego.fecha;
                    consulta.Parameters.Add("@descripcion", SqlDbType.VarChar, 1500).Value = juego.descripcion;
                    consulta.Parameters.Add("@precio", SqlDbType.Decimal).Value = juego.precio;
                    consulta.Parameters["@precio"].Precision = 10;
                    consulta.Parameters["@precio"].Scale = 2;
                    consulta.Parameters.Add("@categoria", SqlDbType.Int).Value = juego.categoria;  
                    consulta.Parameters.Add("@imagen", SqlDbType.VarChar, 255).Value = juego.imagen;
                    consulta.Parameters.Add("@desarrollador", SqlDbType.VarChar, 255).Value = juego.desarrollador;

                    consulta.ExecuteNonQuery();
                    creado = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al crear el juego: " + ex.Message);
                }
                finally
                {
                    conection.Close();
                }
            }

            return creado;
        }

        public bool ReadJuego(ENJuego juego)
        {
            Console.WriteLine(juego.desarrollador);
            bool leido = false;
            string consulta = @"SELECT j.*, c.nombre_categoria 
                        FROM [dbo].[Juego] j 
                        INNER JOIN [dbo].[Categoria] c ON j.categoria = c.id_categoria 
                        WHERE j.id_juego = @id_juego";

            try
            {
                using (SqlConnection conection = new SqlConnection(constring))
                {
                    conection.Open();
                    SqlCommand select = new SqlCommand(consulta, conection);
                    select.Parameters.AddWithValue("@id_juego", juego.id_juego);

                    using (SqlDataReader read = select.ExecuteReader())
                    {
                        if (read.Read())
                        {
                            juego.titulo = read["titulo"].ToString();
                            juego.fecha = DateTime.Parse(read["fecha"].ToString());
                            juego.descripcion = read["descripcion"].ToString();
                            juego.precio = decimal.Parse(read["precio"].ToString());
                            juego.categoria = int.Parse(read["categoria"].ToString());
                            juego.imagen = read["imagen"].ToString();
                            juego.desarrollador = read["desarrollador"].ToString();
                            juego.nombre_categoria = read["nombre_categoria"].ToString();

                            leido = true;
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Error de SQL: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error general: " + ex.Message);
            }

            return leido;
        }




        public bool UpdateJuego(ENJuego juego)
        {
            bool actualizado = false;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "UPDATE Juego SET titulo = @Titulo, fecha = @Fecha, " +
                    "descripcion = @Descripcion, precio = @Precio, categoria = @Categoria, " +
                    "imagen = @Imagen, desarrollador = @Desarrollador WHERE id_juego = @IdJuego";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@Titulo", juego.titulo);
                command.Parameters.AddWithValue("@Fecha", juego.fecha);
                command.Parameters.AddWithValue("@Descripcion", juego.descripcion);
                command.Parameters.AddWithValue("@Precio", juego.precio);
                command.Parameters.AddWithValue("@Categoria", juego.categoria);
                command.Parameters.AddWithValue("@Imagen", juego.imagen);
                command.Parameters.AddWithValue("@Desarrollador", juego.desarrollador);
                command.Parameters.AddWithValue("@IdJuego", juego.id_juego);


                int filasAfectadas = command.ExecuteNonQuery();

                if (filasAfectadas > 0)
                {
                    actualizado = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al actualizar el usuario: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return actualizado;
        }

        public bool DeleteJuego(ENJuego juego)
        {
            bool ok = false;

            try
            {
                using (SqlConnection conection = new SqlConnection(constring))
                {
                    conection.Open();
                    using (SqlCommand consulta = new SqlCommand("DELETE FROM [dbo].[Juego] WHERE id_juego = @id_juego", conection))
                    {
                        consulta.Parameters.Add("@id_juego", SqlDbType.Int).Value = juego.id_juego;
                        consulta.ExecuteNonQuery();
                        ok = true;
                    }
                }
            }
            catch (SqlException exce)
            {
                Console.WriteLine("Error de SQL: " + exce.Message);
            }
            catch (Exception exc)
            {
                Console.WriteLine("Error general: " + exc.Message);
            }

            return ok;
        }

        public DataTable mostrarJuegos()
        {

            DataTable data = new DataTable();

            SqlConnection conection = new SqlConnection(constring);
            try
            {
                SqlDataAdapter info = new SqlDataAdapter("Select titulo, fecha, descripcion, precio, categoria, imagen, desarrollador from Juego where id_juego !=-1", conection);

                info.Fill(data);
            }
            catch (SqlException exce)
            {
                Console.WriteLine("Error de SQL: " + exce.Message);
            }
            catch (Exception exc)
            {
                Console.WriteLine("Error general: " + exc.Message);
            }
            finally
            {
                conection.Close();
            }
            return data;


        }

        public DataTable GetJuegosConCategoria()
        {
            DataTable data = new DataTable();

            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    conection.Open();
                    string query = @"SELECT j.id_juego, j.titulo, j.fecha, j.descripcion, j.precio, j.imagen, j.desarrollador, c.nombre_categoria
                                     FROM Juego j
                                     INNER JOIN Categoria c ON j.categoria = c.id_categoria";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conection);
                    adapter.Fill(data);
                }
                catch (SqlException exce)
                {
                    Console.WriteLine("Error de SQL: " + exce.Message);
                }
                catch (Exception exc)
                {
                    Console.WriteLine("Error general: " + exc.Message);
                }
                finally
                {
                    conection.Close();
                }
            }

            return data;
        }


        public static List<ENJuego> ObtenerJuegosFiltrados(string orden, string busqueda, List<int> categorias, Tuple<decimal?, decimal?> rangoPrecio)
        {
            List<ENJuego> juegos = new List<ENJuego>();
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();
                string consulta = "SELECT * FROM Juego WHERE 1=1";

                if (!string.IsNullOrEmpty(busqueda))
                {
                    consulta += " AND titulo LIKE @busqueda";
                }

                if (categorias != null && categorias.Any())
                {
                    // Generar parámetros para las categorías
                    string categoriaParams = string.Join(",", categorias.Select((_, index) => "@categoria" + index));
                    consulta += " AND categoria IN (" + categoriaParams + ")";

                    // Añadir los parámetros de categorías a la consulta
                    for (int i = 0; i < categorias.Count; i++)
                    {
                        consulta = consulta.Replace("@categoria" + i, categorias[i].ToString());
                    }
                }

                if (rangoPrecio != null)
                {
                    if (rangoPrecio.Item1.HasValue)
                    {
                        consulta += " AND precio >= @precioMin";
                    }

                    if (rangoPrecio.Item2.HasValue)
                    {
                        consulta += " AND precio <= @precioMax";
                    }
                }

                if (orden == "asc")
                {
                    consulta += " ORDER BY precio ASC";
                }
                else if (orden == "desc")
                {
                    consulta += " ORDER BY precio DESC";
                }
                else if (orden == "nuevo")
                {
                    consulta += " ORDER BY fecha DESC";
                }
                else if (orden == "antiguo")
                {
                    consulta += " ORDER BY fecha ASC";
                }
                else if (orden == "alfA")
                {
                    consulta += " ORDER BY titulo ASC";
                }
                else if (orden == "alfZ")
                {
                    consulta += " ORDER BY titulo DESC";
                }

                SqlCommand command = new SqlCommand(consulta, connection);

                if (!string.IsNullOrEmpty(busqueda))
                {
                    command.Parameters.AddWithValue("@busqueda", "%" + busqueda + "%");
                }
                if (rangoPrecio != null)
                {
                    if (rangoPrecio.Item1.HasValue)
                    {
                        command.Parameters.AddWithValue("@precioMin", rangoPrecio.Item1.Value);
                    }

                    if (rangoPrecio.Item2.HasValue)
                    {
                        command.Parameters.AddWithValue("@precioMax", rangoPrecio.Item2.Value);
                    }
                }
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ENJuego juego = new ENJuego();
                    juego.id_juego = Convert.ToInt32(reader["id_juego"]);
                    juego.titulo = reader["titulo"].ToString();
                    juego.fecha = Convert.ToDateTime(reader["fecha"]);
                    juego.descripcion = reader["descripcion"].ToString();
                    juego.precio = Convert.ToDecimal(reader["precio"]);
                    juego.imagen = reader["imagen"].ToString();
                    juego.desarrollador = reader["desarrollador"].ToString();
                    juego.categoria = Convert.ToInt32(reader["categoria"]);

                    juegos.Add(juego);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener juegos: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return juegos;
        }
        public static List<ENJuego> ObtenerTodosLosJuegos()
        {
            List<ENJuego> juegos = new List<ENJuego>();
            string query = "SELECT * FROM Juego";

            using (SqlConnection connection = new SqlConnection(constring))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        ENJuego juego = new ENJuego();
                        juego.id_juego = (int)reader["id_juego"];
                        juego.titulo = reader["titulo"].ToString();
                        juego.fecha = Convert.ToDateTime(reader["fecha"]);
                        juego.descripcion = reader["descripcion"].ToString();
                        juego.precio = (decimal)reader["precio"];
                        juego.imagen = reader["imagen"].ToString();
                        juego.desarrollador = reader["desarrollador"].ToString();
                        juego.categoria = (int)reader["categoria"];

                        juegos.Add(juego);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al obtener todos los juegos: " + ex.Message);
                }
            }
            return juegos;
        }
        /*
        public static List<ENJuego> BuscarJuegos(string busqueda)
        {
            List<ENJuego> juegos = new List<ENJuego>();
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();

                string consulta = "SELECT * FROM Juego WHERE titulo LIKE @Busqueda";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@Busqueda", "%" + busqueda + "%");

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    ENJuego juego = new ENJuego();
                    juego.id_juego = Convert.ToInt32(reader["id_juego"]);
                    juego.titulo = reader["titulo"].ToString();
                    juego.fecha = Convert.ToDateTime(reader["fecha"]);
                    juego.descripcion = reader["descripcion"].ToString();
                    juego.precio = Convert.ToDecimal(reader["precio"]);
                    juego.imagen = reader["imagen"].ToString();
                    juego.desarrollador = reader["desarrollador"].ToString();
                    juego.categoria = Convert.ToInt32(reader["categoria"]);

                    juegos.Add(juego);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener juegos: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return juegos;
        }
        */

        public bool UsuarioHaCompradoJuego(int usuarioId, int idJuego)
        {
            using (SqlConnection connection = new SqlConnection(constring))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Biblioteca WHERE id_usuario = @UsuarioId AND id_juego = @JuegoId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UsuarioId", usuarioId);
                command.Parameters.AddWithValue("@JuegoId", idJuego);

                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }

        public static ENJuego ObtenerJuegoPorId(int id)
        {
            ENJuego juego = null;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();
                string consulta = "SELECT * FROM Juego WHERE id_juego = @id";

                SqlCommand command = new SqlCommand(consulta, connection);
                command.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    juego = new ENJuego();

                    juego.id_juego = Convert.ToInt32(reader["id_juego"]);
                    juego.titulo = reader["titulo"].ToString();
                    juego.fecha = Convert.ToDateTime(reader["fecha"]);
                    juego.descripcion = reader["descripcion"].ToString();
                    juego.precio = Convert.ToDecimal(reader["precio"]);
                    juego.imagen = reader["imagen"].ToString();
                    juego.desarrollador = reader["desarrollador"].ToString();
                    juego.categoria = Convert.ToInt32(reader["categoria"]);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al obtener el juego: " + ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return juego;
        }

    }
}
