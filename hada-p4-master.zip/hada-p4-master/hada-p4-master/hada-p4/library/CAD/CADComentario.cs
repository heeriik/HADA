﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using library;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
using System.Data;

namespace library
{
    public class CADComentario
    {
        private string constring; 
        public CADComentario()
        {
            constring = ConfigurationManager.ConnectionStrings["Database"].ToString();
        }

        public bool CreateComentario(ENComentario comentario)
        {
            bool creado = false;

            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    conection.Open();
                    SqlCommand consulta = new SqlCommand("INSERT INTO [dbo].[Comentario]" +
                                                         "(valoracion, contenido, fecha, id_usuario, id_juego) " +
                                                         "VALUES (@valoracion, @contenido, @fecha, @id_usuario, @id_juego)", conection);

                    consulta.Parameters.Add("@valoracion", SqlDbType.Int).Value = comentario.valoracion;
                    consulta.Parameters.Add("@contenido", SqlDbType.Text).Value = comentario.contenido;
                    consulta.Parameters.Add("@fecha", SqlDbType.DateTime).Value = comentario.fecha;
                    consulta.Parameters.Add("@id_usuario", SqlDbType.Int).Value = comentario.id_usuario;
                    consulta.Parameters.Add("@id_juego", SqlDbType.Int).Value = comentario.id_juego;

                    consulta.ExecuteNonQuery();
                    creado = true;
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("Error de SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error general: " + ex.Message);
                }
            }

            return creado;
        }

        public bool ReadComentario(ENComentario comentario)
        {
            bool leido = false;
            string consulta = "SELECT * FROM [dbo].[Comentario] WHERE id_comentario = @id_comentario";

            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    conection.Open();
                    SqlCommand select = new SqlCommand(consulta, conection);
                    select.Parameters.AddWithValue("@id_comentario", comentario.id_comentario);

                    using (SqlDataReader read = select.ExecuteReader())
                    {
                        if (read.Read())
                        {
                            comentario.valoracion = int.Parse(read["valoracion"].ToString());
                            comentario.contenido = read["contenido"].ToString();
                            comentario.fecha = DateTime.Parse(read["fecha"].ToString());
                            comentario.id_usuario = int.Parse(read["id_usuario"].ToString());
                            comentario.id_juego = int.Parse(read["id_juego"].ToString());
                            leido = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return leido;
        }

        public string UpdateComentario(ENComentario comentario)     // Método para actualizar un comentario (No sé si se usará)
        {
            string resultado = "";

            try
            {
                using (SqlConnection conection = new SqlConnection(constring))
                {
                    conection.Open();

                    using (SqlCommand consulta = new SqlCommand("UPDATE [dbo].[Comentario] SET valoracion = @valoracion, contenido = @contenido, " +
                        "fecha = @fecha, id_usuario = @id_usuario, id_juego = @id_juego WHERE id_comentario = @id_comentario", conection))
                    {
                        consulta.Parameters.Add("@id_comentario", SqlDbType.Int).Value = comentario.id_comentario;
                        consulta.Parameters.Add("@valoracion", SqlDbType.Int).Value = comentario.valoracion;
                        consulta.Parameters.Add("@contenido", SqlDbType.NVarChar).Value = comentario.contenido;
                        consulta.Parameters.Add("@fecha", SqlDbType.DateTime).Value = comentario.fecha;
                        consulta.Parameters.Add("@id_usuario", SqlDbType.Int).Value = comentario.id_usuario;
                        consulta.Parameters.Add("@id_juego", SqlDbType.Int).Value = comentario.id_juego;

                        int filasAfectadas = consulta.ExecuteNonQuery();

                        if (filasAfectadas > 0)
                        {
                            resultado = "Se ha actualizado correctamente";
                        }
                        else
                        {
                            resultado = "No se encontró el comentario para actualizar";
                        }
                    }
                }
            }
            catch (SqlException exce)
            {
                resultado = "Error de SQL: " + exce.Message;
                Console.WriteLine(resultado);
            }
            catch (Exception exc)
            {
                resultado = "Error general: " + exc.Message;
                Console.WriteLine(resultado);
            }

            return resultado;
        }

        public bool DeleteComentario(ENComentario comentario)
        {
            bool ok = false;

            try
            {
                using (SqlConnection conection = new SqlConnection(constring))
                {
                    conection.Open();
                    using (SqlCommand consulta = new SqlCommand("DELETE FROM [dbo].[Comentario] WHERE id_comentario = @id_comentario", conection))
                    {
                        consulta.Parameters.Add("@id_comentario", SqlDbType.Int).Value = comentario.id_comentario;
                        int rowsAffected = consulta.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            ok = true;
                        }
                    }
                }
            }
            catch (SqlException exce)
            {
                Console.WriteLine("Error de SQL: " + exce.Message);
            }
            catch (Exception exc)
            {
                Console.WriteLine("Error general: " + exc.Message);
            }

            return ok;
        }

        public List<ENComentario> GetComentariosPorJuego(int idJuego)
        {
            List<ENComentario> comentarios = new List<ENComentario>();

            using (SqlConnection conection = new SqlConnection(constring))
            {
                try
                {
                    conection.Open();
                    SqlCommand consulta = new SqlCommand("SELECT * FROM [dbo].[Comentario] WHERE id_juego = @id_juego", conection);
                    consulta.Parameters.AddWithValue("@id_juego", idJuego);

                    using (SqlDataReader read = consulta.ExecuteReader())
                    {
                        while (read.Read())
                        {
                            ENComentario comentario = new ENComentario
                            {
                                id_comentario = int.Parse(read["id_comentario"].ToString()),
                                valoracion = int.Parse(read["valoracion"].ToString()),
                                contenido = read["contenido"].ToString(),
                                fecha = DateTime.Parse(read["fecha"].ToString()),
                                id_usuario = int.Parse(read["id_usuario"].ToString()),
                                id_juego = int.Parse(read["id_juego"].ToString())
                            };
                            comentarios.Add(comentario);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al obtener comentarios: " + ex.Message);
                }
            }

            return comentarios;
        }

        public List<dynamic> GetComentariosConUsuario(int idJuego)  // Se obtienen los comentarios relacionados con cada usuario
        {
            List<dynamic> comentariosConUsuario = new List<dynamic>();

            using (SqlConnection con = new SqlConnection(constring))
            {
                string query = @"
            SELECT c.valoracion, c.contenido, c.fecha, u.nombre_usuario 
            FROM Comentario c
            JOIN Usuario u ON c.id_usuario = u.id_usuario
            WHERE c.id_juego = @idJuego";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@idJuego", idJuego);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var comentarioConUsuario = new
                    {
                        Valoracion = reader["valoracion"],
                        Contenido = reader["contenido"],
                        Fecha = reader["fecha"],
                        NombreUsuario = reader["nombre_usuario"] + ":",
                    };

                    comentariosConUsuario.Add(comentarioConUsuario);
                }
            }

            return comentariosConUsuario;
        }

        public double GetPromedio(int idJuego)
        {
            double promedio = -1; // Valor para indicar que no hay valoraciones

            using (SqlConnection connection = new SqlConnection(constring))
            {
                try
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand(
                        "SELECT AVG(valoracion) AS Promedio FROM Comentario WHERE id_juego = @id_juego", connection);
                    cmd.Parameters.AddWithValue("@id_juego", idJuego);

                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value)
                    {
                        promedio = Convert.ToDouble(result);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error al obtener promedio de valoraciones: " + ex.Message);
                }
            }

            return promedio;
        }
    }
}
