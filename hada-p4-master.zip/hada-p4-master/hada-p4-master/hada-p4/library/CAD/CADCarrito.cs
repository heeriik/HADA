﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace library
{
    public class CADCarrito
    {
        private string constring;

        //Definir el constring para acceder a la base de datos
        public CADCarrito() 
        {
            this.constring = ConfigurationManager.ConnectionStrings["database"].ToString();
        }

        //Crear un carrito
        public bool createCarrito(ENCarrito en) 
        {
            SqlConnection connection = null;
            try
            {
                // Abrimos la conexión
                connection = new SqlConnection(constring);
                connection.Open();

                SqlCommand query = new SqlCommand("INSERT INTO [dbo].[Carrito] (id_usuario) VALUES (@ID_USUARIO)", connection);
                query.Parameters.Add("@ID_USUARIO", SqlDbType.Int).Value = en.id_usuario;
                query.ExecuteNonQuery();
                connection.Close();

                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Carrito creation operation has failed. Error: {0}", ex.Message);
                return false;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }

        }

        //Leer un carrito
        public bool readCarrito(ENCarrito en) 
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(constring);
                connection.Open();


                SqlCommand query = new SqlCommand($"SELECT * FROM [dbo].[Carrito] WHERE id_usuario = {en.id_usuario}", connection);
                SqlDataReader result = query.ExecuteReader();
                result.Read();


                if (result.HasRows)
                {
                    en.id_carrito = int.Parse(result["id_carrito"].ToString());
                    en.id_usuario = int.Parse(result["id_usuario"].ToString());
                }
                else
                {
                    return false;
                }

                // Fin
                connection.Close();
                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Carrito read operation has failed. Error: {0}", ex.Message);
                return false;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

        //Actualizar un carrito (No se si sera necesario)
        public bool updateCarrito(ENCarrito en) { return false; }

        //Eliminar un carrito
        public bool deleteCarrito(ENCarrito en) 
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(constring);
                connection.Open();

                SqlCommand query = new SqlCommand($"DELETE FROM [dbo].[Carrito] WHERE id_usuario = {en.id_usuario}", connection);
                query.ExecuteNonQuery();

                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Carrito delete operation has failed. Error: {0}", ex.Message);
                return false;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }


        public int UserTieneCarrito(int id_user)
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(constring);
                connection.Open();


                SqlCommand query = new SqlCommand($"SELECT * FROM [dbo].[Carrito] WHERE id_usuario = {id_user}", connection);
                SqlDataReader result = query.ExecuteReader();
                result.Read();

               

                if (result.HasRows)
                {
                    int x = int.Parse(result["id_carrito"].ToString());
                    connection.Close();
                    return x ;
                }
                else
                {
                    connection.Close();
                    return -1;
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("Carrito UserTieneCarrito operation has failed. Error: {0}", ex.Message);
                return -1;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

        


    }
}