﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System;

namespace library
{
    public class CADLinCarrito
    {
        private string constring;

        //Definir el constring para acceder a la base de datos
        public CADLinCarrito() 
        {
            this.constring = ConfigurationManager.ConnectionStrings["database"].ToString();
        }

        //Crear una linea de carrito
        public bool createLinCarrito(ENLinCarrito en) 
        {
            SqlConnection connection = null;
            try
            {
                // Abrimos la conexión
                connection = new SqlConnection(constring);
                connection.Open();

                SqlCommand query = new SqlCommand("INSERT INTO [dbo].[LinCarrito] (id_carrito, id_juego) VALUES (@ID_CARRITO, @ID_JUEGO)", connection);
                query.Parameters.Add("@ID_CARRITO", SqlDbType.Int).Value = en.id_carrito;
                query.Parameters.Add("@ID_JUEGO", SqlDbType.Int).Value = en.id_juego;
                query.ExecuteNonQuery();
                connection.Close();

                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine("LinCarrito create operation has failed. Error: {0}", ex.Message);
                return false;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

        //Leer una linea de carrito
        public bool readLinCarrito(ENLinCarrito en) 
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(constring);
                connection.Open();

                SqlCommand query = new SqlCommand($"SELECT * FROM [dbo].[LinCarrito] WHERE id_carrito = @ID_CARRITO and id_juego = @ID_JUEGO", connection);
                query.Parameters.Add("@ID_CARRITO", SqlDbType.Int).Value = en.id_carrito;
                query.Parameters.Add("@ID_JUEGO", SqlDbType.Int).Value = en.id_juego;
                SqlDataReader result = query.ExecuteReader();
                result.Read();

                if (result.HasRows)
                {
                    en.id_linea= int.Parse(result["id_linea"].ToString());
                    en.id_carrito = int.Parse(result["id_carrito"].ToString());
                    en.id_juego = int.Parse(result["id_juego"].ToString());
                }
                else
                {
                    // No existe la linfactura
                    return false;
                }

                // Fin
                connection.Close();
                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine("LinCarrito read operation has failed. Error: {0}", ex.Message);
                return false;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

        //Actualizar una linea de carrito (No se si es necesario)
        public bool updateLinCarrito(ENLinCarrito en) { return false; }

        //Eliminar una linea de carrito
        public bool deleteLinCarrito(ENLinCarrito en) 
        {
            SqlConnection connection = null;
            try
            {
                connection = new SqlConnection(constring);
                connection.Open();

                SqlCommand query = new SqlCommand($"DELETE FROM [dbo].[LinCarrito] WHERE id_carrito = @ID_CARRITO and id_juego = @ID_JUEGO", connection);
                query.Parameters.Add("@ID_CARRITO", SqlDbType.Int).Value = en.id_carrito;
                query.Parameters.Add("@ID_JUEGO", SqlDbType.Int).Value = en.id_juego;
                query.ExecuteNonQuery();

                return true;
            }
            catch (SqlException ex)
            {
                Console.WriteLine("LinCarrito delete operation has failed. Error: {0}", ex.Message);
                return false;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

        //Metodo para conseguir todas las lineas de un carrito
        public DataSet getLinCarrito(ENLinCarrito en) 
        {
            SqlConnection connection = null;
            DataSet dataSet = new DataSet();
            try
            {
                connection = new SqlConnection(constring);
                connection.Open();

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT * FROM [dbo].[LinCarrito] WHERE id_carrito = @ID_CARRITO;", connection);
                sqlDataAdapter.SelectCommand.Parameters.Add("@ID_CARRITO", SqlDbType.Int).Value = en.id_carrito;
                sqlDataAdapter.Fill(dataSet, "LinCarrito");
                return dataSet;
            }
            catch (SqlException ex)
            {
                Console.WriteLine("LinCarrito getLinCarrito operation has failed. Error: {0}", ex.Message);
                return dataSet;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

    }
}
