﻿using library;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class Registro : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["UsuarioId"] != null)
            {
                Response.Redirect("~/Default.aspx");
            }
        }
        protected void button_registro_Click(object sender, EventArgs e)
        {
            string nombre = textbox_nombre.Text;
            string correo = textbox_correo.Text;
            string contraseña = textbox_contraseña.Text;
            string confirmarContraseña = textbox_confirmarContraseña.Text;

            label_mensaje_nombre.Text = "";
            label_mensaje_correo.Text = "";
            label_mensaje_contraseña.Text = "";
            label_mensaje_confirmarContraseña.Text = "";

            if (string.IsNullOrEmpty(nombre))
            {
                label_mensaje_nombre.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(correo))
            {
                label_mensaje_correo.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(contraseña))
            {
                label_mensaje_contraseña.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(confirmarContraseña))
            {
                label_mensaje_confirmarContraseña.Text = "Este campo no puede estar vacío";
            }

            if(nombre != "" && correo != "" && contraseña != "" && confirmarContraseña != "")
            {
                ENUsuario usuario = new ENUsuario();

                if (usuario.ExisteCorreo(correo) && contraseña.Length < 6)
                {
                    label_mensaje_correo.Text = "Este correo ya existe";
                    label_mensaje_contraseña.Text = "La contraseña debe tener al menos 6 caracteres";
                    return;
                }
                if (!CorreoValido(correo) && contraseña.Length < 6)
                {
                    label_mensaje_correo.Text = "´El formato del correo electrónico no es válido";
                    label_mensaje_contraseña.Text = "La contraseña debe tener al menos 6 caracteres";
                    return;
                }
                if (usuario.ExisteCorreo(correo))
                {
                    label_mensaje_correo.Text = "´Este correo ya existe";
                    return;
                }
                if (!CorreoValido(correo))
                {
                    label_mensaje_correo.Text = "´El formato del correo electrónico no es válido";
                    return;
                }
                if (contraseña.Length < 6)
                {
                    label_mensaje_contraseña.Text = "La contraseña debe tener al menos 6 caracteres";
                    return;
                }
                if(contraseña != confirmarContraseña)
                {
                    label_mensaje_confirmarContraseña.Text = "Las contraseñas deben coincidir";
                    return;
                }

                if (!usuario.ExisteCorreo(correo) && CorreoValido(correo) && contraseña.Length >= 6 && contraseña == confirmarContraseña)
                {
                    usuario.nombre_usuario = nombre;
                    usuario.correo = correo;
                    usuario.contrasena = contraseña;

                    if (usuario.create())
                    {
                        int idUsuario = CADUsuario.ObtenerIdUsuario(correo);

                        ENUsuario usuarioNuevo = new ENUsuario();
                        usuarioNuevo = CADUsuario.ObtenerUsuarioPorId(idUsuario);

                        Session["usuarioId"] = usuarioNuevo.id_usuario;
                        Session["usuarioNombre"] = usuarioNuevo.nombre_usuario;
                        Session["usuarioCorreo"] = usuarioNuevo.correo;

                        EnviarMensajeBienvenida(usuarioNuevo.correo, usuarioNuevo.nombre_usuario);

                        Response.Redirect("~/Default.aspx");
                    }
                    else
                    {
                        label_mensaje_error.Text = "Error al crear el usuario. Por favor, inténtalo de nuevo.";
                    }
                }
            }
        }
        private bool CorreoValido(string correo)
        {
            string patronCorreo = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

            try
            {
                Regex regex = new Regex(patronCorreo);
                return regex.IsMatch(correo);
            }
            catch (FormatException)
            {
                return false;
            }
        }
        private void EnviarMensajeBienvenida(string correoDestino, string nombreUsuario)
        {
            string correoRemitente = "stealhada2024@gmail.com";
            string contraseñaRemitente = "disjxggodhvwqmuu";
            string asunto = "Bienvenido a Nuestra Web";
            string cuerpo = $"Hola {nombreUsuario},\n\nGracias por registrarte en nuestra web.\n\nSaludos y a disfrutar!";

            MailMessage mail = new MailMessage();
            mail.From = new MailAddress(correoRemitente);
            mail.To.Add(correoDestino);
            mail.Subject = asunto;
            mail.Body = cuerpo;

            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
            smtpClient.Credentials = new NetworkCredential(correoRemitente, contraseñaRemitente);
            smtpClient.EnableSsl = true;

            try
            {
                smtpClient.Send(mail);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al enviar el correo: " + ex.Message);
            }
        }
    }
}