﻿using library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class AdminJuegos : System.Web.UI.Page
    {
        protected List<ENJuego> juegos;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if(Session["usuarioId"] != null)
                {
                    if (Session["usuarioId"].ToString() == "1")
                    {
                        CargarJuegos();
                        CargarCategorias();

                        //solución del problema de eliminar juego
                        if (Request.QueryString["accion"] == "eliminar" && Request.QueryString["idJuego"] != null)
                        {
                            int idJuego = Convert.ToInt32(Request.QueryString["idJuego"]);
                            EliminarJuego(idJuego);
                        }
                    }
                    else
                    {
                        Response.Redirect("~/Default.aspx");
                    }
                }
                else
                {
                    Response.Redirect("~/Default.aspx");
                }
            }
        }
        private void CargarJuegos()
        {
            juegos = CADJuego.ObtenerTodosLosJuegos();
        }
        private void CargarCategorias()
        {
            List<ENCategoria> categorias = CADCategoria.ObtenerCategorias();

            ENCategoria seleccionar = new ENCategoria();
            seleccionar.id_categoria = 0;
            seleccionar.nombre_categoria = "Seleccionar";

            categorias.Insert(0, seleccionar);

            dropdown_adminJuegos_categoria.DataSource = categorias;
            dropdown_adminJuegos_categoria.DataTextField = "nombre_categoria";
            dropdown_adminJuegos_categoria.DataValueField = "id_categoria";
            dropdown_adminJuegos_categoria.DataBind();
        }
        [System.Web.Services.WebMethod()]
        public void EliminarJuego(int? id_juego) {

            if (id_juego.HasValue) // Comprobar si id_juego tiene un valor
            {
                ENJuego juego = new ENJuego();
                juego.id_juego = id_juego.Value;

                if (juego.ReadJuego())
                {
                    if (juego.DeleteJuego())
                    {
                        label_mensaje_error_adminJuegos.ForeColor = System.Drawing.Color.Green;
                        label_mensaje_error_adminJuegos.Text = "Juego eliminado correctamente";

                        Response.Redirect("~/AdminJuegos.aspx");
                    }
                    else
                    {
                        label_mensaje_error_adminJuegos.ForeColor = System.Drawing.Color.Red;
                        label_mensaje_error_adminJuegos.Text = "Error al eliminar el juego";
                    }
                }
                else
                {
                    label_mensaje_error_adminJuegos.ForeColor = System.Drawing.Color.Red;
                    label_mensaje_error_adminJuegos.Text = "Error al leer el juego";
                }
            }
            else
            {
                label_mensaje_error_adminJuegos.ForeColor = System.Drawing.Color.Red;
                label_mensaje_error_adminJuegos.Text = "Error al leer el id del juego";
            }
        }

        protected void button_eliminar_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string idJuegoStr = button.Attributes["data-juegoid"];
            if (int.TryParse(idJuegoStr, out int idJuego))
            {
                // Llamar al método EliminarJuego con el id del juego
                EliminarJuego(idJuego);
            }
        }



        protected void button_agregarJuego_Click(object sender, EventArgs e)
        {
            string titulo = textbox_adminJuegos_titulo.Text;
            string fecha = textbox_adminJuegos_fecha.Text;
            string descripcion = textbox_adminJuegos_descripcion.Text;
            string precio = textbox_adminJuegos_precio.Text;
            string imagen = textbox_adminJuegos_imagenURL.Text;
            string desarrollador = textbox_adminJuegos_desarrollador.Text;
            int categoria = Convert.ToInt32(dropdown_adminJuegos_categoria.SelectedValue);

            label_mensaje_titulo.Text = "";
            label_mensaje_fecha.Text = "";
            label_mensaje_descripcion.Text = "";
            label_mensaje_precio.Text = "";
            label_mensaje_imagenURL.Text = "";
            label_mensaje_desarrollador.Text = "";

            if (string.IsNullOrEmpty(titulo))
            {
                label_mensaje_titulo.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(fecha))
            {
                label_mensaje_fecha.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(descripcion))
            {
                label_mensaje_descripcion.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(precio))
            {
                label_mensaje_precio.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(imagen))
            {
                label_mensaje_imagenURL.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(desarrollador))
            {
                label_mensaje_desarrollador.Text = "Este campo no puede estar vacío";
            }
            if(categoria == 0)
            {
                label_mensaje_categoria.Text = "Debes seleccionar una categoría";
            }

            if(titulo != "" && fecha != "" && descripcion != "" && precio != "" && imagen != "" && desarrollador != "" && categoria != 0)
            {
                ENJuego nuevoJuego = new ENJuego();

                nuevoJuego.titulo = titulo;
                nuevoJuego.fecha = Convert.ToDateTime(fecha);
                nuevoJuego.descripcion = descripcion;
                nuevoJuego.precio = Convert.ToDecimal(precio);
                nuevoJuego.imagen = imagen;
                nuevoJuego.desarrollador = desarrollador;
                nuevoJuego.categoria = Convert.ToInt32(categoria);

                if (nuevoJuego.CreateJuego())
                {
                    LimpiarFormulario();
                    Response.Redirect("~/AdminJuegos.aspx");
                }
                else
                {
                    label_mensaje_error_nuevoJuego.Text = "Error al agregar el juego.";
                }
            }
        }

        protected string ObtenerNombreCategoria(int idCategoria)
        {
            string nombreCategoria = CADCategoria.ObtenerNombreCategoriaPorId(idCategoria);

            return nombreCategoria;
        }


        private void LimpiarFormulario()
        {
            textbox_adminJuegos_titulo.Text = "";
            textbox_adminJuegos_fecha.Text = "";
            textbox_adminJuegos_descripcion.Text = "";
            textbox_adminJuegos_precio.Text = "";
            textbox_adminJuegos_imagenURL.Text = "";
            textbox_adminJuegos_desarrollador.Text = "";
            dropdown_adminJuegos_categoria.SelectedIndex = 0;

            label_mensaje_titulo.Text = "";
            label_mensaje_fecha.Text = "";
            label_mensaje_descripcion.Text = "";
            label_mensaje_precio.Text = "";
            label_mensaje_imagenURL.Text = "";
            label_mensaje_desarrollador.Text = "";
        }
    }
}