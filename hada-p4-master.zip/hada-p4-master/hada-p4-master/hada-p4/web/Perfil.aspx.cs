﻿using library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class Perfil : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["usuarioId"] == null)
                {
                    Response.Redirect("~/InicioSesion.aspx");
                }
                else
                {
                    textbox_nombre.Text = (string)Session["usuarioNombre"];
                    textbox_correo.Text = (string)Session["usuarioCorreo"];
                }
            }
        }
        protected void button_eliminarCuenta_Click(object sender, EventArgs e)
        {
            ENUsuario usuario = CADUsuario.ObtenerUsuarioPorId((int)Session["usuarioId"]);

            if (usuario.delete())
            {
                Response.Redirect("~/Default.aspx");
            }
            else{
                label_mensaje_error.Text = "Error al eliminar el usuario";
            }
        }
        protected void button_perfil_Click(object sender, EventArgs e)
        {
            try
            {
                string nombre = textbox_nombre.Text;
                string correo = textbox_correo.Text;
                string contraseña = textbox_contraseña.Text;
                string confirmarContraseña = textbox_confirmarContraseña.Text;

                label_mensaje_nombre.Text = "";
                label_mensaje_correo.Text = "";
                label_mensaje_contraseña.Text = "";
                label_mensaje_confirmarContraseña.Text = "";
                label_mensaje_error.Text = "";

                if (string.IsNullOrEmpty(nombre))
                {
                    label_mensaje_nombre.Text = "Este campo no puede estar vacío";
                }
                if (string.IsNullOrEmpty(correo))
                {
                    label_mensaje_correo.Text = "Este campo no puede estar vacío";
                }
                if(!string.IsNullOrEmpty(contraseña) && !string.IsNullOrEmpty(confirmarContraseña))
                {
                    if(contraseña != confirmarContraseña)
                    {
                        label_mensaje_confirmarContraseña.Text = "Las contraseñas deben de coincidir";
                    }
                }

                if(nombre != "" && correo != "")
                {
                    ENUsuario usuario = new ENUsuario();
                    int idUsuario = CADUsuario.ObtenerIdUsuario(Convert.ToString(Session["usuarioCorreo"]));
                    usuario = CADUsuario.ObtenerUsuarioPorId(idUsuario);

                    if (usuario == null)
                    {
                        label_mensaje_error.Text = "Error al cargar el usuario.";
                        return;
                    }

                    if (usuario.correo != correo)
                    {
                        if (usuario.ExisteCorreo(correo))
                        {
                            label_mensaje_correo.Text = "Este correo ya existe";
                            return;
                        }

                        if (!CorreoValido(correo))
                        {
                            label_mensaje_correo.Text = "El formato del correo no es válido";
                            return;
                        }
                        usuario.correo = correo;
                    }

                    usuario.nombre_usuario = nombre;

                    if (!string.IsNullOrEmpty(contraseña))
                    {
                        if (contraseña.Length < 6)
                        {
                            label_mensaje_contraseña.Text = "La contraseña debe tener al menos 6 dígitos";
                            return;
                        }

                        if (contraseña != confirmarContraseña)
                        {
                            label_mensaje_confirmarContraseña.Text = "Las contraseñas no coinciden";
                            return;
                        }

                        usuario.contrasena = contraseña;
                    }

                    if (usuario.update())
                    {
                        Session.Remove("usuarioNombre");
                        Session.Remove("usuarioCorreo");

                        Session["usuarioNombre"] = usuario.nombre_usuario;
                        Session["usuarioCorreo"] = usuario.correo;

                        Response.Redirect("~/Perfil.aspx");
                    }
                    else
                    {
                        label_mensaje_error.Text = "Error al actualizar el usuario.";
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al actualizar el perfil: " + ex.Message);
                label_mensaje_error.Text = "Error al actualizar el perfil";
            }
        }
        private bool CorreoValido(string correo)
        {
            string patronCorreo = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

            try
            {
                Regex regex = new Regex(patronCorreo);
                return regex.IsMatch(correo);
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}