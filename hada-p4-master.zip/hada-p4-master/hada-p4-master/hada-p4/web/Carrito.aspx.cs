﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.DynamicData;
using System.Web.UI;
using System.Web.UI.WebControls;
using library;
using System.Net;
using System.Net.Mail;
using System.Text;


namespace web
{
    public partial class Carrito : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["usuarioId"] != null)
            {
                if (!IsPostBack)
                {
                    ENUsuario loggedUser = CADUsuario.ObtenerUsuarioPorId((int)Session["usuarioId"]);

                    CADCarrito c = new CADCarrito();

                    ENCarrito carrito = new ENCarrito(loggedUser.id_usuario);


                    if (c.UserTieneCarrito(loggedUser.id_usuario) == -1)
                    {
                        c.createCarrito(carrito);
                    }

                    carrito.readCarrito();

                    CargarCarrito(carrito);
                } 
            }

        


        }

        private void CargarCarrito(ENCarrito carrito)
        {
            DataTable JuegosEnCarro = MostrarCarrito(carrito);

            juegosEnCarro.DataSource = JuegosEnCarro;

            juegosEnCarro.DataBind();
        }

        private DataTable GenerarTabla()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("id_juego", typeof(int));
            dataTable.Columns.Add("titulo", typeof(string));
            dataTable.Columns.Add("UrlImagen", typeof(string));
            dataTable.Columns.Add("price", typeof(string));

            return dataTable;
        }

        private DataTable MostrarCarrito(ENCarrito carrito)
        {
            try
            {
                DataTable dataTable = GenerarTabla();

                ENLinCarrito linCarrito = new ENLinCarrito();

                linCarrito.id_carrito = carrito.id_carrito;

                DataSet dataSet = linCarrito.getLinCarrito();

                ENJuego aux = new ENJuego();

                decimal totalprecio = 0;

                foreach (DataRow row in dataSet.Tables[0].Rows)
                {
                    aux.id_juego = int.Parse(row["id_juego"].ToString());

                    aux.ReadJuego();

                    dataTable.Rows.Add(aux.id_juego, aux.titulo, aux.imagen, aux.precio);

                    totalprecio += aux.precio;
                }

                Pt.Text = totalprecio.ToString() + " €";

                return dataTable;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al cargar el carrito: " + ex.Message);
            }

            return null;
            
        }


        protected void juegos_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            try
            {
                if (e.CommandName == "Eliminar")
                {
                    ENUsuario loggedUser = CADUsuario.ObtenerUsuarioPorId((int)Session["usuarioId"]);

                    int index = Convert.ToInt32(e.CommandArgument);


                    ENCarrito carrito = new ENCarrito(loggedUser.id_usuario);

                    carrito.readCarrito();

                    ENLinCarrito linCarrito = new ENLinCarrito();

                    linCarrito.id_carrito = carrito.id_carrito;

                    DataSet data = linCarrito.getLinCarrito();

                    int juego_borrar = -1;

                    int ind = 0;

                    ENJuego aux = new ENJuego();

                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        aux.id_juego = int.Parse(row["id_juego"].ToString());

                        aux.ReadJuego();

                        if (index == ind)
                        {
                            juego_borrar = aux.id_juego;
                        }

                        ind++;
                    }

                    ENLinCarrito borrar = new ENLinCarrito(new CADCarrito().UserTieneCarrito(loggedUser.id_usuario), juego_borrar);

                    new CADLinCarrito().deleteLinCarrito(borrar);

                    CargarCarrito(carrito);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al vaciar el carrito: " + ex.Message);
            }
        }

        protected void onVaciarCarrito(object sender, EventArgs e)
        {
            try
            {
                ENUsuario loggedUser = CADUsuario.ObtenerUsuarioPorId((int)Session["usuarioId"]);


                ENCarrito carrito = new ENCarrito(loggedUser.id_usuario);

                carrito.readCarrito();

                ENLinCarrito linCarrito = new ENLinCarrito();

                linCarrito.id_carrito = carrito.id_carrito;

                DataSet data = linCarrito.getLinCarrito();

                ENJuego aux = new ENJuego();

                foreach (DataRow row in data.Tables[0].Rows)
                {
                    aux.id_juego = int.Parse(row["id_juego"].ToString());

                    aux.ReadJuego();

                    ENLinCarrito borrar = new ENLinCarrito(new CADCarrito().UserTieneCarrito(loggedUser.id_usuario), aux.id_juego);

                    new CADLinCarrito().deleteLinCarrito(borrar);

                }

                CargarCarrito(carrito);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al vaciar el carrito: " + ex.Message);
            }

        }

        protected void onComprar(object sender, EventArgs e)
        {
            try
            {
                // 1. Obtener el carrito del usuario
                ENUsuario loggedUser = CADUsuario.ObtenerUsuarioPorId((int)Session["usuarioId"]);

                ENCarrito carrito = new ENCarrito(loggedUser.id_usuario);

                carrito.readCarrito();

                // 1,5. Comprobaciones

                ENLinCarrito linCarrito = new ENLinCarrito();

                linCarrito.id_carrito = carrito.id_carrito;

                DataSet data = linCarrito.getLinCarrito();

                if(data.Tables[0].Rows.Count == 0)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('No hay juegos en el carrito');", true);
                    throw new Exception("No hay juegos en el carrito");
                }

                ENJuego aux = new ENJuego();

                decimal totalprecio = 0;

                foreach (DataRow row in data.Tables[0].Rows)
                {
                    aux.id_juego = int.Parse(row["id_juego"].ToString());

                    aux.ReadJuego();

                    totalprecio += aux.precio;
                }

                if (loggedUser.saldo_disponible < totalprecio)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('No tienes suficiente saldo');", true);
                    throw new Exception("No hay saldo");
                }


                // 2. Obtener las líneas de pedido asociadas al carrito
                CADPedido pedido = new CADPedido();
                bool compra_realizada = pedido.RealizarCompra(loggedUser.id_usuario);

                // 3. Actualizar el saldo del usuario
                if (compra_realizada)
                {
                    CADUsuario.AgregarImporte(loggedUser.id_usuario, -1 * totalprecio);
                }

                // 4. Generar y enviar factura                         
                CADFactura factura = new CADFactura();
                factura.realizarFactura(loggedUser.id_usuario);

                CargarCarrito(carrito);

                // Mensaje de confirmación
                Response.Write("<script>alert('Compra realizada con éxito. Se ha enviado la factura a su correo.');</script>");


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al realizar la compra: " + ex.Message);
            }
            
        }
        

    }
}