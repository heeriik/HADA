﻿using library;
using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace web
{
    public partial class Juego : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                Comentar_boton.Visible = false;
                // Leer el parámetro id de la cadena de consulta
                string idJuegoStr = Request.QueryString["id"];
                if (!string.IsNullOrEmpty(idJuegoStr))
                {
                    int idJuego;
                    if (int.TryParse(idJuegoStr, out idJuego))
                    {
                        // Usar el idJuego para cargar los detalles del juego
                        ENJuego juego = new ENJuego();
                        juego.id_juego = idJuego;

                        CADJuego cadJuego = new CADJuego();
                        if (cadJuego.ReadJuego(juego))
                        {
                            Imagen_juego.ImageUrl = juego.imagen;
                            Titulo.Text = juego.titulo;
                            Descripcion.Text = juego.descripcion;
                            Desarrollador.Text = juego.desarrollador;
                            Fecha.Text = juego.fecha.ToString("yyyy-MM-dd");
                            Precio.Text = juego.precio.ToString() + " €";
                            Categoria.Text = juego.nombre_categoria;
                        }

                        if (Session["usuarioId"] != null)
                        {
                            int usuarioId = (int)Session["usuarioId"];
                            CADJuego cadjuego = new CADJuego();
                            if (cadjuego.UsuarioHaCompradoJuego(usuarioId, idJuego))    // Se comprueba si el juego esta en la biblioteca del usuario
                            {
                                añadir_al_carrito.Visible = false;
                                Comentar_boton.Visible = true;
                                Mensaje.Visible = false;
                            }
                            else
                            {
                                añadir_al_carrito.Visible = true;
                                Comentar_boton.Visible = false;
                                Mensaje.Visible = true;
                            }
                        }
                        CADComentario cadComentario = new CADComentario();
                        double promedio = cadComentario.GetPromedio(idJuego);
                        if (promedio == -1)
                        {
                            PromedioValoraciones.Text = "Valoracion media: -";
                        }
                        else
                        {
                            PromedioValoraciones.Text = "Valoracion media: " + promedio.ToString("0.0");
                        }
                        CargarComentarios(juego.id_juego);
                    }
                    else
                    {
                        Response.Redirect("~/Default.aspx");
                    }
                }
                else
                {
                    Response.Redirect("~/Default.aspx");
                }
            }


        }



        private void CargarComentarios(int idJuego)
        {
            CADComentario cadComentario = new CADComentario();
            var comentariosConUsuario = cadComentario.GetComentariosConUsuario(idJuego);

            if (comentariosConUsuario.Count == 0)
            {
                // No hay comentarios, mostrar el mensaje
                MensajeNoComentarios.Visible = true;
                MensajeNoComentarios.Text = "\n De momento no hay comentarios. Se el primero en dar su opnión !!!";
                RepeaterComentario.Visible = false;
            }
            else
            {
                RepeaterComentario.DataSource = comentariosConUsuario;
                RepeaterComentario.DataBind();
            }
        }



        protected void Button_Juego_al_carrito(object sender, EventArgs e)
        {
            if (Session["usuarioId"] != null)
            {
                // Verifica si el ID del juego es válido
                string idJuegoStr = Request.QueryString["id"];
                int idJuego;
                int.TryParse(idJuegoStr, out idJuego);

                // Agrega el juego al carrito
                ENCarrito carro = new ENCarrito();
                bool juegoAgregado = carro.MeterEnCarrito(idJuego, (int)Session["usuarioId"]);

                if (juegoAgregado)
                {
                    // Si se ha agregado el juego correctamente redirige al usuario al carrito
                    Response.Redirect("~/Carrito.aspx");
                }
                else
                {
                    // Mostrar mensaje informativo
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Hubo un problema al agregar el juego al carrito');", true);
                }
            }
            else
            {
                // Redirige al usuario a la página de inicio de sesión
                Response.Redirect("~/InicioSesion.aspx");
            }
        }

        protected void btnComentar_Click(object sender, EventArgs e)
        {
            panelComentario.Visible = true; // Mostrar el panel de comentario
        }

        protected void btnEnviarComentario_Click(object sender, EventArgs e)
        {
            if (Session["usuarioId"] != null)
            {
                int usuarioId = (int)Session["usuarioId"];
                string comentario = txtComentario.Text; // Obtener el texto del comentario

                string idJuegoStr = Request.QueryString["id"];
                int idJuego;
                int.TryParse(idJuegoStr, out idJuego);

                int numEstrellas = ObtenerValoracionSeleccionada(); // Obtener el valor de la valoración

                ENComentario nuevoComentario = new ENComentario
                {
                    valoracion = numEstrellas,
                    contenido = comentario,
                    fecha = DateTime.Now, // Se asignan la fecha y hora actual
                    id_usuario = usuarioId,
                    id_juego = idJuego
                };

                // Guardar el comentario en la base de datos
                CADComentario cadComentario = new CADComentario();
                bool comentarioGuardado = cadComentario.CreateComentario(nuevoComentario);

                if (comentarioGuardado)
                {
                    panelComentario.Visible = false;
                    // Comentario guardado correctamente, actualiza la lista de comentarios
                    txtComentario.Text = string.Empty;
                    LimpiarValoracion();
                    Response.Redirect(Request.RawUrl);
                }
            }
            else
            {
                Response.Redirect("~/InicioSesion.aspx");
            }
        }

        private int ObtenerValoracionSeleccionada() // Valoracion proporcionada al crear un comentario
        {
            if (star5.Checked)
            {
                return 5;
            }
            else if (star4.Checked)
            {
                return 4;
            }
            else if (star3.Checked)
            {
                return 3;
            }
            else if (star2.Checked)
            {
                return 2;
            }
            else if (star1.Checked)
            {
                return 1;
            }
            return 0;
        }

        private void LimpiarValoracion()
        {
            star1.Checked = false;
            star2.Checked = false;
            star3.Checked = false;
            star4.Checked = false;
            star5.Checked = false;
        }


        protected string GetEstrellas(object valoracion)    // Método para representar la valoración de un comentario con estrellas
        {
            int rating = Convert.ToInt32(valoracion);
            StringBuilder stars = new StringBuilder();

            for (int i = 1; i <= 5; i++)
            {
                if (i <= rating)
                {
                    stars.Append("&#9733;"); // Estrella llena
                }
                else
                {
                    stars.Append("&#9734;"); // Estrella vacía
                }
            }

            return stars.ToString();
        }
    }
}