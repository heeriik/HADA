﻿using library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.DynamicData;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{   

    public partial class Biblioteca : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["usuarioId"] == null)
                {
                    Response.Redirect("~/Default.aspx");
                }
                CargarCategorias();
                MostrarJuegosDeBiblioteca();
            }
            

        }

        

        protected void button_inicio_busqueda_Click(object sender, EventArgs e)
        {
            string busqueda = textbox_inicio_busqueda.Text.Trim();

            MostrarBuscadorDeBiblioteca(busqueda);
        }
        protected void checkBoxList_categoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Obtener las categorías seleccionadas
            List<string> categoriasSeleccionadas = new List<string>();
            foreach (ListItem item in checkBoxList_categoria.Items)
            {
                if (item.Selected)
                {
                    categoriasSeleccionadas.Add(item.Value);
                }
            }

            // Aplicar el filtro de categoría y mostrar los juegos filtrados
            MostrarJuegosFiltradosPorCategoria(categoriasSeleccionadas);
        }
        private void CargarCategorias()
        {
            List<ENCategoria> categorias = CADCategoria.ObtenerCategorias();

            checkBoxList_categoria.DataSource = categorias;
            checkBoxList_categoria.DataTextField = "nombre_categoria";
            checkBoxList_categoria.DataValueField = "id_categoria";
            checkBoxList_categoria.DataBind();
        }


        private void MostrarJuegosDeBiblioteca()
        {
            int idUsuario = (int)Session["usuarioId"];

            CADBiblioteca bibliotecaManager = new CADBiblioteca();
            List<int> juegosEnBiblioteca = bibliotecaManager.ObtenerJuegosEnBibliotecaPorUsuario(idUsuario);
            List<ENJuego> juegos = new List<ENJuego>();

            foreach (int idJuego in juegosEnBiblioteca)
            {
                ENJuego juego = bibliotecaManager.ObtenerJuegosBD(idJuego);
                if (juego != null)
                {
                    juegos.Add(juego);
                }
            }

            // Asignar la lista de juegos al control Repeater para mostrarlos en la página
            RepeaterJuegos.DataSource = juegos;
            RepeaterJuegos.DataBind();
        }
        private void MostrarBuscadorDeBiblioteca(string terminoBusqueda)
        {
            int idUsuario = (int)Session["usuarioId"];

            CADBiblioteca bibliotecaManager = new CADBiblioteca();
            List<int> juegosEnBiblioteca = bibliotecaManager.ObtenerJuegosEnBibliotecaPorUsuario(idUsuario);
            List<ENJuego> juegos = new List<ENJuego>();

            // Filtrar juegos según el término de búsqueda utilizando LINQ
            juegos = (from idJuego in juegosEnBiblioteca
                      let juego = bibliotecaManager.ObtenerJuegosBD(idJuego)
                      where juego != null && juego.titulo != null && juego.titulo.ToLower().Contains(terminoBusqueda.ToLower())
                      select juego).ToList();

            // Asignar la lista de juegos al control Repeater para mostrarlos en la página
            RepeaterJuegos.DataSource = juegos;
            RepeaterJuegos.DataBind();
        }

        private void MostrarJuegosFiltradosPorCategoria(List<string> categorias)
        {
            int idUsuario = (int)Session["usuarioId"];

            CADBiblioteca bibliotecaManager = new CADBiblioteca();
            List<int> juegosEnBiblioteca = bibliotecaManager.ObtenerJuegosEnBibliotecaPorUsuario(idUsuario);
            List<ENJuego> juegos = new List<ENJuego>();

            foreach (int idJuego in juegosEnBiblioteca)
            {
                ENJuego juego = bibliotecaManager.ObtenerJuegosBD(idJuego);
                if (juego != null && categorias.Contains(juego.categoria.ToString()))
                {
                    juegos.Add(juego);
                }
            }
            if(categorias.Count == 0)
            {
                juegos = juegosEnBiblioteca.Select(idJuego => bibliotecaManager.ObtenerJuegosBD(idJuego)).ToList();
            }
            // Asignar la lista de juegos al control Repeater para mostrarlos en la página
            RepeaterJuegos.DataSource = juegos;
            RepeaterJuegos.DataBind();
        }   
    }
}
