﻿using library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class EditarJuego : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if(Request.QueryString["id"] != null)
                {
                    int idJuego;

                    if (int.TryParse(Request.QueryString["id"], out idJuego))
                    {
                        CargarCategorias();
                        CargarDatosJuego(idJuego);
                    }
                    else
                    {
                        label_mensaje_error_editarJuego.Text = "Error al leer el id del juego";
                    }
                }
                else
                {
                    label_mensaje_error_editarJuego.Text = "Error.";
                }
            }
        }
        private void CargarCategorias()
        {
            List<ENCategoria> categorias = CADCategoria.ObtenerCategorias();

            ENCategoria seleccionar = new ENCategoria();
            seleccionar.id_categoria = 0;
            seleccionar.nombre_categoria = "Seleccionar";

            categorias.Insert(0, seleccionar);

            dropdown_adminJuegos_categoria.DataSource = categorias;
            dropdown_adminJuegos_categoria.DataTextField = "nombre_categoria";
            dropdown_adminJuegos_categoria.DataValueField = "id_categoria";
            dropdown_adminJuegos_categoria.DataBind();
        }
        private void CargarDatosJuego(int id)
        {
            ENJuego juego = new ENJuego();
            juego = CADJuego.ObtenerJuegoPorId(id);

            if(juego != null)
            {
                textbox_adminJuegos_titulo.Text = juego.titulo;
                textbox_adminJuegos_fecha.Text = juego.fecha.ToString("yyyy-MM-dd");
                textbox_adminJuegos_descripcion.Text = juego.descripcion;
                textbox_adminJuegos_precio.Text = juego.precio.ToString("F2");
                textbox_adminJuegos_imagenURL.Text = juego.imagen;
                textbox_adminJuegos_desarrollador.Text = juego.desarrollador;
                dropdown_adminJuegos_categoria.SelectedValue = juego.categoria.ToString();
            }
            else
            {
                label_mensaje_error_editarJuego.Text = "Error, no se ha podido leer el juego";
            }
        }
        protected void button_guardarJuego_Click(object sender, EventArgs e)
        {
            string titulo = textbox_adminJuegos_titulo.Text;
            string fecha = textbox_adminJuegos_fecha.Text;
            string descripcion = textbox_adminJuegos_descripcion.Text;
            string precio = textbox_adminJuegos_precio.Text;
            string imagen = textbox_adminJuegos_imagenURL.Text;
            string desarrollador = textbox_adminJuegos_desarrollador.Text;
            int categoria = Convert.ToInt32(dropdown_adminJuegos_categoria.SelectedValue);




            label_mensaje_titulo.Text = "";
            label_mensaje_fecha.Text = "";
            label_mensaje_descripcion.Text = "";
            label_mensaje_precio.Text = "";
            label_mensaje_imagenURL.Text = "";
            label_mensaje_desarrollador.Text = "";

            if (string.IsNullOrEmpty(titulo))
            {
                label_mensaje_titulo.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(fecha))
            {
                label_mensaje_fecha.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(descripcion))
            {
                label_mensaje_descripcion.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(precio))
            {
                label_mensaje_precio.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(imagen))
            {
                label_mensaje_imagenURL.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(desarrollador))
            {
                label_mensaje_desarrollador.Text = "Este campo no puede estar vacío";
            }
            if (categoria == 0)
            {
                label_mensaje_categoria.Text = "Debes seleccionar una categoría";
            }

            if (titulo != "" && fecha != "" && descripcion != "" && precio != "" && imagen != "" && desarrollador != "" && categoria != 0)
            {

                //ENJuego juego = new ENJuego();
                //Buscamos el id del juego por el titulo antes de que se actualice

                //solucion si cambian el titulo
                ENJuego juego = new ENJuego();
                int id = Convert.ToInt32(Request.QueryString["id"]);
                juego = CADJuego.ObtenerJuegoPorId(id);

                juego.id_juego = id;
                juego.titulo = titulo;
                juego.fecha = Convert.ToDateTime(fecha);
                juego.descripcion = descripcion;
                juego.precio = Convert.ToDecimal(precio);
                juego.imagen = imagen;
                juego.desarrollador = desarrollador;
                juego.categoria = Convert.ToInt32(categoria);

                //Solucion del perro
                if(juego.UpdateNuevoJuego())
                {
                    Response.Redirect("~/AdminJuegos.aspx");
                }
                else
                {
                    label_mensaje_error_editarJuego.Text = "Error al actualizar el juego";
                }
            }
        }
        protected void button_cancelarJuego_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AdminJuegos.aspx");
        }
    }
}