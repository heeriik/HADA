﻿using library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                admin_usuarios.Visible = false;
                admin_juegos.Visible = false;

                if(Session["usuarioId"] != null)
                {
                    int idUsuario = Convert.ToInt32(Session["usuarioId"]);

                    ENUsuario usuario = new ENUsuario();
                    usuario = CADUsuario.ObtenerUsuarioPorId(idUsuario);

                    if (Session["usuarioId"].ToString() == "1")
                    {
                        admin_usuarios.Visible = true;
                        admin_juegos.Visible = true;
                    }
                    else
                    {
                        mostrar_saldo.Visible = true;
                        hyperLink_saldo.Visible = true;

                        label_saldo.Text = usuario.saldo_disponible.ToString("F2");
                    }

                    string usuarioNombre = usuario.nombre_usuario;

                    MostrarElementosUsuarioLogueado();

                    saludoUsuario.Text = "¡Hola, " + usuarioNombre + "!";
                }
                else
                {
                    MostrarElementosUsuarioNoLogueado();
                }
            }
        }

        private void MostrarElementosUsuarioLogueado()
        {
            inicio.Visible = false;
            registro.Visible = false;

            iconoNombreUsuario.Visible = true;
            configuracion.Visible = true;
            iconoCarrito.Visible = true;
        }
        private void MostrarElementosUsuarioNoLogueado()
        {
            inicio.Visible = true;
            registro.Visible = true;

            iconoNombreUsuario.Visible = false;
            configuracion.Visible = false;
            carrito.Visible = false;
            mostrar_saldo.Visible = false;
            hyperLink_saldo.Visible = false;
        }
    }
}