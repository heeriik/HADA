﻿using library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class InicioSesion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if(Session["usuarioId"] == null)
                {
                    label_mensaje_correo.Text = "";
                    label_mensaje_contraseña.Text = "";

                    formularioInicioSesion.Visible = true;
                    formularioCorreo.Visible = false;
                    formularioRecuperacion.Visible = false;
                }
                else
                {
                    Response.Redirect("~/Default.aspx");
                }
            }
        }
        protected void button_inicioSesion_Click(object sender, EventArgs e)
        {
            try
            {
                string correo = textbox_correo.Text;
                string contraseña = textbox_contraseña.Text;

                if (string.IsNullOrEmpty(correo))
                {
                    label_mensaje_correo.Text = "Debes ingresar un correo.";
                    label_mensaje_contraseña.Text = "";
                    return;
                }

                if (string.IsNullOrEmpty(contraseña))
                {
                    label_mensaje_correo.Text = "";
                    label_mensaje_contraseña.Text = "Debes ingresar una contraseña.";
                    return;
                }

                ENUsuario usuario = new ENUsuario();

                if (usuario.ValidarCredenciales(correo, contraseña))
                {
                    int usuarioId = usuario.ObtenerIdUsuario(correo);
                    usuario = usuario.ObtenerUsuarioPorId(usuarioId);

                    if (usuario != null)
                    {
                        Session["usuarioId"] = usuarioId;
                        Session["usuarioNombre"] = usuario.nombre_usuario;
                        Session["usuarioCorreo"] = usuario.correo;

                        Response.Redirect("~/Default.aspx");
                    }
                    else
                    {
                        label_mensaje_correo.Text = "";
                        label_mensaje_contraseña.Text = "Error al iniciar sesión. Inténtalo de nuevo.";
                    }
                }
                else
                {
                    label_mensaje_correo.Text = "";
                    label_mensaje_contraseña.Text = "El correo o la contraseña son incorrectos. Inténtalo de nuevo.";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al iniciar sesión: " + ex.Message);
                label_mensaje_correo.Text = "Error al iniciar sesión. Por favor, inténtalo de nuevo.";
            }
        }

        protected void button_recuperar_correo_Click(object sender, EventArgs e)
        {
            formularioInicioSesion.Visible = false;
            formularioCorreo.Visible = false;
            formularioRecuperacion.Visible = true;
            
            string correo = textbox_correo_contraseña.Text;

            if(correo == "")
            {
                label_mensaje_correo_recuperar.Text = "Debes poner un correo";
            }
            else
            {
                ENUsuario usuario = new ENUsuario();

                if (usuario.ExisteCorreo(correo))
                {
                    int idUsuario = CADUsuario.ObtenerIdUsuario(correo);
                    usuario = CADUsuario.ObtenerUsuarioPorId(idUsuario);

                    Session["usuarioId"] = usuario.id_usuario;
                    Session["usuarioNombre"] = usuario.nombre_usuario;
                    Session["usuarioCorreo"] = usuario.correo;
                    formularioCorreo.Visible = false;
                }
                else
                {
                    label_mensaje_correo_recuperar.Text = "Este correo no existe";
                }
            }
        }
        protected void button_recuperar_contraseña_Click(object sender, EventArgs e)
        {
            formularioInicioSesion.Visible = true;
            formularioCorreo.Visible = false;
            formularioRecuperacion.Visible = false;
        }
    }
}