﻿using library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class Saldo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if(Session["usuarioId"] == null)
                {
                    Response.Redirect("~/Default.aspx");
                }
            }
        }

        protected void AgregarSaldo_Click(object sender, EventArgs e)
        {
            string numeroTarjeta1 = textbox_numeroTarjeta_1.Text;
            string numeroTarjeta2 = textbox_numeroTarjeta_2.Text;
            string numeroTarjeta3 = textbox_numeroTarjeta_3.Text;
            string numeroTarjeta4 = textbox_numeroTarjeta_4.Text;
            string fechaVencimientoMM = textbox_fechaVencimiento_1.Text;
            string fechaVencimientoAA = textbox_fechaVencimiento_2.Text;
            string cvv = textbox_cvv.Text;
            string nombreTitular = textbox_nombreTitular.Text;
            string importe = textbox_importe.Text;

            if(EsNumero(numeroTarjeta1) && EsNumero(numeroTarjeta2) && 
                EsNumero(numeroTarjeta3) && EsNumero(numeroTarjeta4) &&
                EsNumero(fechaVencimientoMM) && EsNumero(fechaVencimientoAA) && 
                EsNumero(cvv) && EsNumero(importe))
            {
                if(numeroTarjeta1.Length == 4 && numeroTarjeta2.Length == 4 &&
                    numeroTarjeta3.Length == 4 && numeroTarjeta4.Length == 4 &&
                    fechaVencimientoMM.Length == 2 && fechaVencimientoAA.Length == 2 &&
                    cvv.Length == 3)
                {
                    int fechaVenMM = Convert.ToInt32(fechaVencimientoMM);

                    if (fechaVenMM >= 1 && fechaVenMM <= 12)
                    {
                        ENUsuario usuario = new ENUsuario();
                        string correo = Convert.ToString(Session["usuarioCorreo"]);
                        int idUsuario = CADUsuario.ObtenerIdUsuario(correo);
                        usuario = CADUsuario.ObtenerUsuarioPorId(idUsuario);

                        decimal importeTotal = decimal.Parse(importe);

                        if (usuario.AgregarSaldo(usuario.id_usuario, importeTotal))
                        {
                            textbox_numeroTarjeta_1.Text = "";
                            textbox_numeroTarjeta_2.Text = "";
                            textbox_numeroTarjeta_3.Text = "";
                            textbox_numeroTarjeta_4.Text = "";

                            Response.Redirect("~/Saldo.aspx");
                        }
                        else
                        {
                            label_mensaje_error.ForeColor = System.Drawing.Color.Red;
                            label_mensaje_error.Text = "Error al agregar saldo";
                        }
                    }
                    else
                    {
                        label_mensaje_error.ForeColor = System.Drawing.Color.Red;
                        label_mensaje_error.Text = "Error al agregar saldo";
                    }
                }
                else
                {
                    label_mensaje_error.ForeColor = System.Drawing.Color.Red;
                    label_mensaje_error.Text = "Error al agregar saldo";
                }
            }
            else
            {
                label_mensaje_error.ForeColor = System.Drawing.Color.Red;
                label_mensaje_error.Text = "Por favor, ingrese solo números en los campos correspondientes";
            }
        }

        private bool EsNumero(string texto)
        {
            foreach (char c in texto)
            {
                if (!char.IsDigit(c))
                {
                    return false;
                }
            }
            return true;
        }
    }
}