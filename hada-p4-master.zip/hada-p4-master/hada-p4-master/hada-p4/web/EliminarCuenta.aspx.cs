﻿using library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class EliminarCuenta : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["usuarioId"] == null)
                {
                    Response.Redirect("~/Default.aspx");
                }
            }
        }
        protected void button_eliminarCuenta_cancelar_Click(object sender, EventArgs e)
        {
            try
            {
                Response.Redirect("~/Perfil.aspx");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al eliminar la cuenta: " + ex.Message);
            }
        }
        protected void button_eliminarCuenta_confirmar_Click(object sender, EventArgs e)
        {
            try
            {
                ENUsuario usuario = CADUsuario.ObtenerUsuarioPorId((int)Session["usuarioId"]);

                if (usuario.delete())
                { 
                    Session.Remove("usuarioId");
                    Session.Remove("usuarioNombre");
                    Session.Remove("usuarioCorreo");

                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    Console.WriteLine("Error al eliminar la cuenta");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al eliminar cuenta: " + ex.Message);
            }
        }
    }
}