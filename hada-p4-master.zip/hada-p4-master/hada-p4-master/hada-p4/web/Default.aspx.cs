﻿using library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace web
{
    public partial class Default : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CargarCategorias();
                CargarJuegos("default", null, null, null);
            }
        }
        private void CargarJuegos(string orden, string busqueda, List<int> categorias, Tuple<decimal?, decimal?> rangoPrecio)
        {
            List<ENJuego> juegos;

            juegos = CADJuego.ObtenerJuegosFiltrados(orden, busqueda, categorias, rangoPrecio);

            repeaterJuegos.DataSource = juegos;
            repeaterJuegos.DataBind();
        }
        private void CargarCategorias()
        {
            List<ENCategoria> categorias = CADCategoria.ObtenerCategorias();

            checkBoxList_categoria.DataSource = categorias;
            checkBoxList_categoria.DataTextField = "nombre_categoria";
            checkBoxList_categoria.DataValueField = "id_categoria";
            checkBoxList_categoria.DataBind();
        }

        //Botón para buscar juegos según su título
        protected void button_inicio_busqueda_Click(object sender, EventArgs e)
        {
            string busqueda = textbox_inicio_busqueda.Text.Trim();

            CargarJuegos(dropDownListOrdenacion.SelectedValue, busqueda, null, null);
        }
        protected void dropDownListOrdenacion_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<int> categoriasSeleccionadas = checkBoxList_categoria.Items.Cast<ListItem>()
                .Where(i => i.Selected)
                .Select(i => int.Parse(i.Value))
                .ToList();

            decimal? precioMin = null;
            decimal? precioMax = null;

            if (decimal.TryParse(textbox_precioMin.Text, out decimal min))
            {
                precioMin = min;
            }
            if (decimal.TryParse(textbox_precioMax.Text, out decimal max))
            {
                precioMax = max;
            }
            var rangoPrecio = new Tuple<decimal?, decimal?>(precioMin, precioMax);

            CargarJuegos(dropDownListOrdenacion.SelectedValue, null, categoriasSeleccionadas, rangoPrecio);
        }
        protected void checkBoxList_categoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<int> categoriasSeleccionadas = checkBoxList_categoria.Items.Cast<ListItem>()
                .Where(i => i.Selected)
                .Select(i => int.Parse(i.Value))
                .ToList();

            // Obtener el orden seleccionado en el DropDownList de ordenación
            string orden = dropDownListOrdenacion.SelectedValue;

            // Obtener el rango de precios
            decimal? precioMin = null;
            decimal? precioMax = null;

            if (decimal.TryParse(textbox_precioMin.Text, out decimal min))
            {
                precioMin = min;
            }
            if (decimal.TryParse(textbox_precioMax.Text, out decimal max))
            {
                precioMax = max;
            }
            var rangoPrecio = new Tuple<decimal?, decimal?>(precioMin, precioMax);

            CargarJuegos(orden, null, categoriasSeleccionadas, rangoPrecio);
        }
        protected void button_filtroPrecio_Click(object sender, EventArgs e)
        {
            List<int> categoriasSeleccionadas = checkBoxList_categoria.Items.Cast<ListItem>()
                .Where(i => i.Selected)
                .Select(i => int.Parse(i.Value))
                .ToList();

            decimal? precioMin = null;
            decimal? precioMax = null;

            if (decimal.TryParse(textbox_precioMin.Text, out decimal min))
            {
                precioMin = min;
            }
            if (decimal.TryParse(textbox_precioMax.Text, out decimal max))
            {
                precioMax = max;
            }
            var rangoPrecio = new Tuple<decimal?, decimal?>(precioMin, precioMax);
            string orden = dropDownListOrdenacion.SelectedValue;

            CargarJuegos(orden, null, categoriasSeleccionadas, rangoPrecio);
        }
        protected void imgBtnJuego_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton imageButton = (ImageButton)sender;

            int idJuego = Convert.ToInt32(imageButton.CommandArgument);

            Response.Redirect("Juego.aspx?id=" + idJuego);
        }
        protected void button_añadir_juego_Click(object sender, EventArgs e)
        {
            if(Session["usuarioId"] != null)
            {
                Button button = (Button)sender;
                int id_juego = int.Parse(button.CommandArgument);

                ENCarrito carro = new ENCarrito();
                bool juegoAgregado = carro.MeterEnCarrito(id_juego,(int)Session["usuarioId"]);

                if (juegoAgregado)
                {
                    // Si se ha agregado el juego correctamente redirige al usuario al carrito
                    Response.Redirect("~/Carrito.aspx");
                }
                else
                {
                    // Mostrar mensaje informativo
                    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('Hubo un problema al agregar el juego al carrito');", true);
                }
            }
            else
            {
                Response.Redirect("~/InicioSesion.aspx");
            }
        }
    }
}