﻿using library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace web
{
    public partial class AdminUsuarios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if(Session["usuarioId"] != null)
                {
                    if (Session["usuarioId"].ToString() == "1")
                    {
                        label_mensaje_error_adminUsuarios.Text = "";
                        label_mensaje_error.Text = "";

                        CargarUsuarios();
                    }
                    else
                    {
                        Response.Redirect("~/Default.aspx");
                    }
                }
                else
                {
                    Response.Redirect("~/Default.aspx");
                }
            }
        }
        
        private void CargarUsuarios()
        {
            List<ENUsuario> usuarios = CADUsuario.ObtenerUsuarios();
            
            gridView_adminUsuarios.DataSource = usuarios;
            gridView_adminUsuarios.DataBind();
        }

        protected void gridView_adminUsuarios_rowEditing(object sender, GridViewEditEventArgs e)
        {
            label_mensaje_error_adminUsuarios.Text = "";

            gridView_adminUsuarios.EditIndex = e.NewEditIndex;
            CargarUsuarios();
        }
        protected void gridView_adminUsuarios_rowCancellingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            label_mensaje_error_adminUsuarios.Text = "";

            gridView_adminUsuarios.EditIndex = -1;
            CargarUsuarios();
        }
        protected void gridView_adminUsuarios_rowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            label_mensaje_error_adminUsuarios.Text = "";

            GridViewRow row = gridView_adminUsuarios.Rows[e.RowIndex];

            int id = Convert.ToInt32(gridView_adminUsuarios.DataKeys[e.RowIndex].Values[0]);

            string nombre = (row.Cells[1].Controls[0] as TextBox).Text;
            string correo = (row.Cells[2].Controls[0] as TextBox).Text;

            ENUsuario usuario = new ENUsuario();
            usuario = usuario.ObtenerUsuarioPorId(id);

            if (usuario == null)
            {
                label_mensaje_error_adminUsuarios.Text = "Error, usuario no encontrado";
                return;
            }

            if (usuario.correo != correo)
            {
                if (usuario.ExisteCorreo(correo))
                {
                    label_mensaje_error_adminUsuarios.Text = "Error, el correo ya existe";
                    gridView_adminUsuarios.EditIndex = -1;
                    CargarUsuarios();
                    return;
                }

                // Verificar si el nuevo correo es válido
                if (!CorreoValido(correo))
                {
                    label_mensaje_error_adminUsuarios.Text = "Error, el formato del correo no es válido";
                    gridView_adminUsuarios.EditIndex = -1;
                    CargarUsuarios();
                    return;
                }
            }
            usuario.id_usuario = id;
            usuario.nombre_usuario = nombre;
            usuario.correo = correo;

            if (usuario.ActualizarUsuario())
            {
                gridView_adminUsuarios.EditIndex = -1;
                CargarUsuarios();
            }
            else
            {
                label_mensaje_error_adminUsuarios.Text = "Error, no se pudo actualizar el usuario";
            }
        }
        protected void gridView_adminUsuarios_rowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            label_mensaje_error_adminUsuarios.Text = "";

            int id = Convert.ToInt32(gridView_adminUsuarios.DataKeys[e.RowIndex].Values[0]);

            ENUsuario usuario = CADUsuario.ObtenerUsuarioPorId(id);

            usuario.delete();

            CargarUsuarios();
        }
        protected void button_adminUsuarios_guardar_Click(object sender, EventArgs e)
        {
            string nombre = textbox_adminUsuarios_nombre.Text;
            string correo = textbox_adminUsuarios_correo.Text;
            string contraseña = textbox_adminUsuarios_contraseña.Text;

            label_mensaje_error.Text = "";
            label_mensaje_nombre.Text = "";
            label_mensaje_correo.Text = "";
            label_mensaje_contraseña.Text = "";

            if (string.IsNullOrEmpty(nombre))
            {
                label_mensaje_nombre.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(correo))
            {
                label_mensaje_correo.Text = "Este campo no puede estar vacío";
            }
            if (string.IsNullOrEmpty(contraseña))
            {
                label_mensaje_contraseña.Text = "Este campo no puede estar vacío";
            }

            if (nombre != "" && correo != "" && contraseña != "")
            {
                ENUsuario usuario = new ENUsuario();

                if (usuario.ExisteCorreo(correo) && contraseña.Length < 6)
                {
                    label_mensaje_correo.Text = "´Este correo ya existe";
                    label_mensaje_contraseña.Text = "La contraseña debe tener al menos 6 caracteres";
                    return;
                }
                if (!CorreoValido(correo) && contraseña.Length < 6)
                {
                    label_mensaje_correo.Text = "´El formato del correo electrónico no es válido";
                    label_mensaje_contraseña.Text = "La contraseña debe tener al menos 6 caracteres";
                    return;
                }
                if (usuario.ExisteCorreo(correo))
                {
                    label_mensaje_correo.Text = "´Este correo ya existe";
                    return;
                }
                if (!CorreoValido(correo))
                {
                    label_mensaje_correo.Text = "´El formato del correo electrónico no es válido";
                    return;
                }
                if (contraseña.Length < 6)
                {
                    label_mensaje_contraseña.Text = "La contraseña debe tener al menos 6 caracteres";
                    return;
                }

                if (!usuario.ExisteCorreo(correo) && CorreoValido(correo) && contraseña.Length >= 6)
                {
                    usuario.nombre_usuario = nombre;
                    usuario.correo = correo;
                    usuario.contrasena = contraseña;

                    if (usuario.create())
                    {
                        CargarUsuarios();
                    }
                    else
                    {
                        label_mensaje_error.Text = "Error al crear el usuario. Por favor, inténtalo de nuevo.";
                    }
                }
            }
        }
        private bool CorreoValido(string correo)
        {
            string patronCorreo = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

            try
            {
                Regex regex = new Regex(patronCorreo);
                return regex.IsMatch(correo);
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}