# hada-p4 #

## *Componentes del grupo* ##
* López Arpa, Raúl (Coordinador)
  * 48681442X
  * rla28@alu.ua.es
  * rla28-ua
* Paz Juan, Enrique
  * 48826316F
  * epjp1@alu.ua.es
  * epjp199-uniali
* Ikaev Krasnov, Erik
  * 04722934E
  * ei16@alu.ua.es
  * ei16-ua
* Bravo Carmona, Eduardo
  * 20527292E
  * ebc46@alu.ua.es
  * ebc46-ua
* García de las Bayonas Cortés, Jorge
  * 48725801W
  * jgdl11@alu.ua.es
  * jgdl11-ua

## *Descripción* ##
Nuestra aplicación web consiste la venta y distribución de videojuegos en línea para una amplia gama de plataformas, desde consolas de última generación hasta PC.

Nuestro objetivo es proporcionar a los aficionados de los videojuegos un destino único donde puedan descubrir, explorar y adquirir sus juegos favoritos de manera conveniente y segura, mientras disfrutan de una experiencia de compra personalizada.

Los usuarios pueden explorar fácilmente nuestro catálogo mediante una navegación intuitiva y filtros avanzados.

## *Parte pública* ##
- Exploración de videojuegos: Los usuarios pueden explorar el catálogo completo de videojuegos disponibles en la tienda.
- Búsqueda y Filtros de juegos: Los usuarios pueden realizar búsquedas de los videojuegos deseados y se ofrecen opciones de filtros para refinar la búsqueda y encontrar juegos específicos de manera eficiente.
- Registro de cuenta: Se ofrece la opción de registrarse como usuario registrado para acceder a funcionalidades adicionales en la parte privada de la aplicación.
- Comentarios y valoraciones de videojuegos: Los usuarios pueden leer comentarios sobre los diferentes videojuegos disponibles en la tienda.

| **Entidad de negocio** | **Descripción** |
| :- | :- |
| ENJuego |  Representa un juego disponible en la tienda |
| ENCategoria | Categorías en las que se clasifican los juegos para facilitar la navegación |

## *Parte privada* ##
- Acceso completo al catálogo de videojuegos: Los usuarios registrados tienen acceso completo al catálogo de juegos, incluyendo detalles y opciones de compra.
- Gestión de perfil de usuario: Los usuarios pueden editar su perfil, incluyendo información personal como nombre, dirección, etc. Se ofrece la opción de modificar alguno de sus datos, como nombre, contraseña, etc.
- Soporte y servicio al cliente: Se ofrece soporte técnico y servicio al cliente a través de un mensaje por email. Los usuarios registrados pueden enviar consultas y recibir respuestas personalizadas sobre problemas o preguntas relacionadas con la plataforma.
- Reserva de juegos: Si un juego todavia no ha llegado a la tienda pero se prevee que lo haga en poco tiempo los usuarios podrán reservar dicho juego y obtenerlo cuando salga.
- Alquiler y Compra de juegos: Los usuarios pueden elegir entre alquilar un juego durante un tiempo limitado o comprar dicho juego durante un tiempo indefinido.
- Historial de compras: Los usuarios registrados pueden acceder a su historial de compras, donde pueden ver un registro detallados de todas las compras realizadas anteriormente en la tienda.
- Valorar un videojuego: Los usuarios registrados tienen la capacidad de valorar y puntuar los videojuegos que han adquirido o probado.
- Darse de baja: Los usuarios registrados tienen la opción de darse de baja en cualquier momento, eliminando su cuenta y cualquier información asociada.

| **Entidad de negocio** | **Descripción** |
| :- | :- |
| ENUsuario | Representa un usuario que se ha registrado en la web |
| ENCarrito | Almacena los juegos seleccionados por el usuario antes de realizar el pago |
| ENLinCarrito | Almacena una línea de carrito |
| ENComentario | Representa un comentario y valoracion realizado por un usuario registrado sobre un juego específico |
| ENFactura | Representa las facturas generadas para las compras realizadas por los usuarios registrados |
| ENLinFactura | Almacena una línea de factura |
| ENPedido | Representa un pedido realizado por un usuario registrado en la tienda de videojuegos |
| ENLinPedido | Representa una línea individual dentro de un pedido, que corresponde a un producto específico seleccionado por el usuario |
| ENListaDeseos | Permite a los usuarios guardar y gestionar una lista de juegos favoritos dentro de la plataforma |

## *Posibles mejoras* ##
- Enviar email con la información del pedido.
- Cambio de idioma.
- Modo oscuro de la página.
- Las búsquedas recientes se almacenan y al abrir el buscador se muestra un listado con dichas búsquedas para mayor comodidad.
- Añadir calendario de futuros eventos/ofertas.
- Implementar una inteligencia artifical que nos muestre en la pantalla inicial juegos similares a los que hemos comprado.
- Habilitar la opción de introducir un código de descuento al hacer las compras.
- Añadir una función de cada compra realizada, el usuario consigue puntos para subir de nivel (uso decorativo o dar la función de ventaja sobre las futuras compras).

## *Esquema BB.DD.* ##
[Archivo PDF](BBDD/BBDD.pdf)

## *Entrega Final* ##
[Carpeta BD](BBDD)

Nombre de la base de datos: *Database*, *Database.mdf*

### *Presentación* ###
[Presentación](Presentación)

### *Usuarios de Ejemplo* ###
| **Email** | **Password**| **Rol** |
| :- | :- | :- |
| admin@admin.com | admin1234 | Admin |
| usuario1@gmail.com | 12345678 | Normal |
| usuario2@gmail.com | 12345678 | Normal |
| squid@gmail.com | 12341234 | Normal |
| fede@gmail.com | fedemola07 | Normal |
| demon@gmail.com | plg4657R | Normal |
| gael@gmail.com | abcdzywx | Normal |
| rodri@gmail.com | 12341234 | Normal |

### *Tareas Realizadas por cada Miembro* ###
| **Integrante** | **Tarea** | **Observaciones** |
| :- | :- | :- |
| Raúl | Coordinación | - |
| Raúl | ENUsuario y CADUsuario | - |
| Edu | ENCategoria y CADCategoria | - |
| Edu | ENJuego y CADJuego | - |
| Edu | ENComentario y CADComentario | - |
| Erik | ENBiblioteca y CADBiblioteca | Completado entero por Erik |
| Enrique | ENCarrito y CADCarrito | - |
| Enrique | ENLinCarrito y CADLinCarrito | - |
| Erik | ENPedido y CADPedido | Completado entero por Erik |
| Erik | ENLinPedido y CADLinPedido | Completado entero por Erik |
| Jorge | ENFactura y CADFactura | - |
| Jorge | ENLinFactura y CADLinFactura | - |
| Raúl | AdminJuegos.aspx | - |
| Raúl | AdminJuegos.aspx.cs | - |
| Raúl | AdminUsuarios.aspx | - |
| Raúl | AdminUsuarios.aspx.cs | - |
| Erik | Biblioteca.aspx | Completado entero por Erik |
| Erik | Biblioteca.aspx.cs | Completado entero por Erik |
| Enrique | Carrito.aspx | - |
| Enrique | Carrito.aspx.cs | - |
| Raúl | CerrarSesion.aspx | - |
| Raúl | CerrarSesion.aspx.cs | - |
| Jorge | Default.aspx | - |
| Jorge | Default.aspx.cs | - |
| Raúl | EditarJuego.aspx | - |
| Raúl | EditarJuego.aspx.cs | - |
| Raúl | EliminarCuenta.aspx | - |
| Raúl | EliminarCuenta.aspx.cs | - |
| Raúl | InicioSesion.aspx | - |
| Raúl | InicioSesion.aspx.cs | - |
| Edu | Juego.aspx | - |
| Edu | Juego.aspx.cs | - |
| Raúl | Perfil.aspx | - |
| Raúl | Perfil.aspx.cs | - |
| Raúl | Registro.aspx | - |
| Raúl | Registro.aspx.cs | - |
| Raúl | Saldo.aspx | - |
| Raúl | Saldo.aspx.cs | - |
| Raúl | Site1.Master | - |
| Raúl | Site1.Master.cs | - |
| Raúl | Web.config | - |

### *Tareas añadidas/detalladas* ###
| **Integrante** | **Texto**|
| :- | :- |
| Erik | -Ayuda directa en (Lin)Factura y el Email<br> -Ayuda y corrección de eliminar y editar en AdminJuegos (únicamnete en la BBDD)<br> -Correción en ENCarrito(un detalle para poder crear Pedido)<br>  - Añadir una función para el botón de añadirCompra en Carrito.aspx<br> -Corrección en CADJuegos y ENJuegos por AdminJuegos |

### *Extras* ###
| **Tarea** | **Implementado por** | **Detalles** |
| :- | :- | :- |
| Enviar Mail Registro | Raúl | Envía un mail cuando el usuario registra. |
| Enviar Mail Factura | Jorge/Erik | Envía un mail de la factura cuando un usuario realiza una compra. |
| Niveles Fortaleza Contraseña | Raúl | Dependiendo de la contraseña introducida, se mostrará el nivel de fortaleza de la contraseña ('Débil', 'Media', 'Fuerte' o 'Muy Fuerte'). |
| CheckBox Contraseña | Raúl | En los campos 'Contraseña' y 'ConfirmarContraseña' se han añadido unos checkboxs para cambiar el modo de 'Password' a 'Text' y viceversa. |
| Estrellas Valoración Comentario | Eduardo | Un usuario registrado y haya iniciado sesión, cuando haya comprado un juego, podrá hacer un comentario sobre ese juego valorándolo seleccionando de 1 a 5 estrellas según su valoración. |
